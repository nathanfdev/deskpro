webpackJsonp([1],{

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("X4AL");


/***/ }),

/***/ "BZHq":
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || Function("return this")() || (1,eval)("this");
} catch(e) {
	// This works if the window reference is available
	if(typeof window === "object")
		g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),

/***/ "X4AL":
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {var require;var require;(function(f){if(true){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.ErrorWrapper = f()}})(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return require(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
(function (global){
(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.ErrorSubclass = f()}})(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
/* eslint-disable prefer-reflect */

var ErrorSubclass = function ErrorSubclass() {
  for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  var message = args[0];

  var _error = Error.apply(this, args);

  Object.defineProperty(this, 'message', { value: message });
  Object.defineProperty(this, 'name', {
    value: this.constructor.displayName || this.constructor.name
  });

  if (Error.captureStackTrace) {
    Error.captureStackTrace(this, this.constructor);
  } else {
    Object.defineProperty(this, 'stack', {
      get: function get() {
        return _error.stack;
      }
    });
  }
};

ErrorSubclass.prototype = Error.prototype;

ErrorSubclass.prototype.toString = function toString() {
  return this.name + ': ' + this.message;
};

exports.default = ErrorSubclass;

},{}]},{},[1])(1)
});
}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{}],2:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _errorSubclass = require('error-subclass');

var _errorSubclass2 = _interopRequireDefault(_errorSubclass);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } /* eslint-disable prefer-reflect */ // for browser compatibility

var ErrorWrapper = function (_ErrorSubclass) {
  _inherits(ErrorWrapper, _ErrorSubclass);

  function ErrorWrapper(message, childError) {
    _classCallCheck(this, ErrorWrapper);

    var _this = _possibleConstructorReturn(this, (ErrorWrapper.__proto__ || Object.getPrototypeOf(ErrorWrapper)).call(this, message));

    _this.childError = childError;

    var stackDescriptor = Object.getOwnPropertyDescriptor(_this, 'stack');
    var getStack = stackDescriptor.get || function () {
      return stackDescriptor.value;
    };

    Object.defineProperty(_this, 'stack', {
      get: function get() {
        return getStack.call(_this) + '\nCaused by: ' + _this.childError.stack;
      }
    });
    return _this;
  }

  return ErrorWrapper;
}(_errorSubclass2.default);

exports.default = ErrorWrapper;

},{"error-subclass":1}]},{},[2])(2)
});
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__("BZHq")))

/***/ })

},[3]);
//# sourceMappingURL=vendor.js.map