webpackJsonp([1],{

/***/ "//Fk":
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__("U5ju"), __esModule: true };

/***/ }),

/***/ "0K3L":
/***/ (function(module, exports, __webpack_require__) {


var clean = __webpack_require__("nMX2")

/**
 * Export.
 */

module.exports = toSpaceCase

/**
 * Convert a `string` to space case.
 *
 * @param {String} string
 * @return {String}
 */

function toSpaceCase(string) {
  return clean(string).replace(/[\W_]+(.|$)/g, function (matches, match) {
    return match ? ' ' + match : ''
  }).trim()
}


/***/ }),

/***/ 1:
/***/ (function(module, exports) {

module.exports = DeskproAppsSDKReact;

/***/ }),

/***/ "2KxR":
/***/ (function(module, exports) {

module.exports = function(it, Constructor, name, forbiddenField){
  if(!(it instanceof Constructor) || (forbiddenField !== undefined && forbiddenField in it)){
    throw TypeError(name + ': incorrect invocation!');
  } return it;
};

/***/ }),

/***/ "2WNi":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("QuO2");


/***/ }),

/***/ "6mYA":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getPrototypeOf = __webpack_require__("Zx67");

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__("Zrlr");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__("wxAW");

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__("zwoO");

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__("Pf15");

var _inherits3 = _interopRequireDefault(_inherits2);

var _errorWrapper = __webpack_require__("X4AL");

var _errorWrapper2 = _interopRequireDefault(_errorWrapper);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var TrelloApiError = function (_ErrorWrapper) {
  (0, _inherits3.default)(TrelloApiError, _ErrorWrapper);

  function TrelloApiError(message, originalError, httpResponse) {
    (0, _classCallCheck3.default)(this, TrelloApiError);

    var _this = (0, _possibleConstructorReturn3.default)(this, (TrelloApiError.__proto__ || (0, _getPrototypeOf2.default)(TrelloApiError)).call(this, message, originalError));

    _this.httpResponse = httpResponse;
    return _this;
  }

  (0, _createClass3.default)(TrelloApiError, [{
    key: 'response',
    get: function get() {
      return this.httpResponse;
    }
  }, {
    key: 'code',
    get: function get() {
      return 'TrelloApiError';
    }
  }]);
  return TrelloApiError;
}(_errorWrapper2.default);

exports.default = TrelloApiError;

/***/ }),

/***/ "7W7s":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _classCallCheck2 = __webpack_require__("Zrlr");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var TrelloList =
/**
 * @param {String} id
 * @param {String} name
 */
function TrelloList(id, name) {
  (0, _classCallCheck3.default)(this, TrelloList);

  this.id = id;
  this.name = name;
};

exports.default = TrelloList;

/***/ }),

/***/ "7ksl":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _classCallCheck2 = __webpack_require__("Zrlr");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var TrelloBoard =
/**
 * @param {String} id
 * @param {String} name
 */
function TrelloBoard(id, name) {
  (0, _classCallCheck3.default)(this, TrelloBoard);

  this.id = id;
  this.name = name;
};

exports.default = TrelloBoard;

/***/ }),

/***/ "82Mu":
/***/ (function(module, exports, __webpack_require__) {

var global    = __webpack_require__("7KvD")
  , macrotask = __webpack_require__("L42u").set
  , Observer  = global.MutationObserver || global.WebKitMutationObserver
  , process   = global.process
  , Promise   = global.Promise
  , isNode    = __webpack_require__("R9M2")(process) == 'process';

module.exports = function(){
  var head, last, notify;

  var flush = function(){
    var parent, fn;
    if(isNode && (parent = process.domain))parent.exit();
    while(head){
      fn   = head.fn;
      head = head.next;
      try {
        fn();
      } catch(e){
        if(head)notify();
        else last = undefined;
        throw e;
      }
    } last = undefined;
    if(parent)parent.enter();
  };

  // Node.js
  if(isNode){
    notify = function(){
      process.nextTick(flush);
    };
  // browsers with MutationObserver
  } else if(Observer){
    var toggle = true
      , node   = document.createTextNode('');
    new Observer(flush).observe(node, {characterData: true}); // eslint-disable-line no-new
    notify = function(){
      node.data = toggle = !toggle;
    };
  // environments with maybe non-completely correct, but existent Promise
  } else if(Promise && Promise.resolve){
    var promise = Promise.resolve();
    notify = function(){
      promise.then(flush);
    };
  // for other environments - macrotask based on:
  // - setImmediate
  // - MessageChannel
  // - window.postMessag
  // - onreadystatechange
  // - setTimeout
  } else {
    notify = function(){
      // strange IE + webpack dev server bug - use .call(global)
      macrotask.call(global, flush);
    };
  }

  return function(fn){
    var task = {fn: fn, next: undefined};
    if(last)last.next = task;
    if(!head){
      head = task;
      notify();
    } last = task;
  };
};

/***/ }),

/***/ "8ri3":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Scrollbars = undefined;

var _Scrollbars = __webpack_require__("elAt");

var _Scrollbars2 = _interopRequireDefault(_Scrollbars);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

exports["default"] = _Scrollbars2["default"];
exports.Scrollbars = _Scrollbars2["default"];

/***/ }),

/***/ "AlEQ":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getPrototypeOf = __webpack_require__("Zx67");

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__("Zrlr");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__("wxAW");

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__("zwoO");

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__("Pf15");

var _inherits3 = _interopRequireDefault(_inherits2);

var _errorWrapper = __webpack_require__("X4AL");

var _errorWrapper2 = _interopRequireDefault(_errorWrapper);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var AuthenticationRequiredError = function (_ErrorWrapper) {
  (0, _inherits3.default)(AuthenticationRequiredError, _ErrorWrapper);

  function AuthenticationRequiredError() {
    (0, _classCallCheck3.default)(this, AuthenticationRequiredError);
    return (0, _possibleConstructorReturn3.default)(this, (AuthenticationRequiredError.__proto__ || (0, _getPrototypeOf2.default)(AuthenticationRequiredError)).apply(this, arguments));
  }

  (0, _createClass3.default)(AuthenticationRequiredError, [{
    key: 'code',
    get: function get() {
      return 'AuthenticationRequiredError';
    }
  }]);
  return AuthenticationRequiredError;
}(_errorWrapper2.default);

exports.default = AuthenticationRequiredError;

/***/ }),

/***/ "CXw9":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY            = __webpack_require__("O4g8")
  , global             = __webpack_require__("7KvD")
  , ctx                = __webpack_require__("+ZMJ")
  , classof            = __webpack_require__("RY/4")
  , $export            = __webpack_require__("kM2E")
  , isObject           = __webpack_require__("EqjI")
  , aFunction          = __webpack_require__("lOnJ")
  , anInstance         = __webpack_require__("2KxR")
  , forOf              = __webpack_require__("NWt+")
  , speciesConstructor = __webpack_require__("t8x9")
  , task               = __webpack_require__("L42u").set
  , microtask          = __webpack_require__("82Mu")()
  , PROMISE            = 'Promise'
  , TypeError          = global.TypeError
  , process            = global.process
  , $Promise           = global[PROMISE]
  , process            = global.process
  , isNode             = classof(process) == 'process'
  , empty              = function(){ /* empty */ }
  , Internal, GenericPromiseCapability, Wrapper;

var USE_NATIVE = !!function(){
  try {
    // correct subclassing with @@species support
    var promise     = $Promise.resolve(1)
      , FakePromise = (promise.constructor = {})[__webpack_require__("dSzd")('species')] = function(exec){ exec(empty, empty); };
    // unhandled rejections tracking support, NodeJS Promise without it fails @@species test
    return (isNode || typeof PromiseRejectionEvent == 'function') && promise.then(empty) instanceof FakePromise;
  } catch(e){ /* empty */ }
}();

// helpers
var sameConstructor = function(a, b){
  // with library wrapper special case
  return a === b || a === $Promise && b === Wrapper;
};
var isThenable = function(it){
  var then;
  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
};
var newPromiseCapability = function(C){
  return sameConstructor($Promise, C)
    ? new PromiseCapability(C)
    : new GenericPromiseCapability(C);
};
var PromiseCapability = GenericPromiseCapability = function(C){
  var resolve, reject;
  this.promise = new C(function($$resolve, $$reject){
    if(resolve !== undefined || reject !== undefined)throw TypeError('Bad Promise constructor');
    resolve = $$resolve;
    reject  = $$reject;
  });
  this.resolve = aFunction(resolve);
  this.reject  = aFunction(reject);
};
var perform = function(exec){
  try {
    exec();
  } catch(e){
    return {error: e};
  }
};
var notify = function(promise, isReject){
  if(promise._n)return;
  promise._n = true;
  var chain = promise._c;
  microtask(function(){
    var value = promise._v
      , ok    = promise._s == 1
      , i     = 0;
    var run = function(reaction){
      var handler = ok ? reaction.ok : reaction.fail
        , resolve = reaction.resolve
        , reject  = reaction.reject
        , domain  = reaction.domain
        , result, then;
      try {
        if(handler){
          if(!ok){
            if(promise._h == 2)onHandleUnhandled(promise);
            promise._h = 1;
          }
          if(handler === true)result = value;
          else {
            if(domain)domain.enter();
            result = handler(value);
            if(domain)domain.exit();
          }
          if(result === reaction.promise){
            reject(TypeError('Promise-chain cycle'));
          } else if(then = isThenable(result)){
            then.call(result, resolve, reject);
          } else resolve(result);
        } else reject(value);
      } catch(e){
        reject(e);
      }
    };
    while(chain.length > i)run(chain[i++]); // variable length - can't use forEach
    promise._c = [];
    promise._n = false;
    if(isReject && !promise._h)onUnhandled(promise);
  });
};
var onUnhandled = function(promise){
  task.call(global, function(){
    var value = promise._v
      , abrupt, handler, console;
    if(isUnhandled(promise)){
      abrupt = perform(function(){
        if(isNode){
          process.emit('unhandledRejection', value, promise);
        } else if(handler = global.onunhandledrejection){
          handler({promise: promise, reason: value});
        } else if((console = global.console) && console.error){
          console.error('Unhandled promise rejection', value);
        }
      });
      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
      promise._h = isNode || isUnhandled(promise) ? 2 : 1;
    } promise._a = undefined;
    if(abrupt)throw abrupt.error;
  });
};
var isUnhandled = function(promise){
  if(promise._h == 1)return false;
  var chain = promise._a || promise._c
    , i     = 0
    , reaction;
  while(chain.length > i){
    reaction = chain[i++];
    if(reaction.fail || !isUnhandled(reaction.promise))return false;
  } return true;
};
var onHandleUnhandled = function(promise){
  task.call(global, function(){
    var handler;
    if(isNode){
      process.emit('rejectionHandled', promise);
    } else if(handler = global.onrejectionhandled){
      handler({promise: promise, reason: promise._v});
    }
  });
};
var $reject = function(value){
  var promise = this;
  if(promise._d)return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  promise._v = value;
  promise._s = 2;
  if(!promise._a)promise._a = promise._c.slice();
  notify(promise, true);
};
var $resolve = function(value){
  var promise = this
    , then;
  if(promise._d)return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  try {
    if(promise === value)throw TypeError("Promise can't be resolved itself");
    if(then = isThenable(value)){
      microtask(function(){
        var wrapper = {_w: promise, _d: false}; // wrap
        try {
          then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1));
        } catch(e){
          $reject.call(wrapper, e);
        }
      });
    } else {
      promise._v = value;
      promise._s = 1;
      notify(promise, false);
    }
  } catch(e){
    $reject.call({_w: promise, _d: false}, e); // wrap
  }
};

// constructor polyfill
if(!USE_NATIVE){
  // 25.4.3.1 Promise(executor)
  $Promise = function Promise(executor){
    anInstance(this, $Promise, PROMISE, '_h');
    aFunction(executor);
    Internal.call(this);
    try {
      executor(ctx($resolve, this, 1), ctx($reject, this, 1));
    } catch(err){
      $reject.call(this, err);
    }
  };
  Internal = function Promise(executor){
    this._c = [];             // <- awaiting reactions
    this._a = undefined;      // <- checked in isUnhandled reactions
    this._s = 0;              // <- state
    this._d = false;          // <- done
    this._v = undefined;      // <- value
    this._h = 0;              // <- rejection state, 0 - default, 1 - handled, 2 - unhandled
    this._n = false;          // <- notify
  };
  Internal.prototype = __webpack_require__("xH/j")($Promise.prototype, {
    // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
    then: function then(onFulfilled, onRejected){
      var reaction    = newPromiseCapability(speciesConstructor(this, $Promise));
      reaction.ok     = typeof onFulfilled == 'function' ? onFulfilled : true;
      reaction.fail   = typeof onRejected == 'function' && onRejected;
      reaction.domain = isNode ? process.domain : undefined;
      this._c.push(reaction);
      if(this._a)this._a.push(reaction);
      if(this._s)notify(this, false);
      return reaction.promise;
    },
    // 25.4.5.1 Promise.prototype.catch(onRejected)
    'catch': function(onRejected){
      return this.then(undefined, onRejected);
    }
  });
  PromiseCapability = function(){
    var promise  = new Internal;
    this.promise = promise;
    this.resolve = ctx($resolve, promise, 1);
    this.reject  = ctx($reject, promise, 1);
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, {Promise: $Promise});
__webpack_require__("e6n0")($Promise, PROMISE);
__webpack_require__("bRrM")(PROMISE);
Wrapper = __webpack_require__("FeBl")[PROMISE];

// statics
$export($export.S + $export.F * !USE_NATIVE, PROMISE, {
  // 25.4.4.5 Promise.reject(r)
  reject: function reject(r){
    var capability = newPromiseCapability(this)
      , $$reject   = capability.reject;
    $$reject(r);
    return capability.promise;
  }
});
$export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
  // 25.4.4.6 Promise.resolve(x)
  resolve: function resolve(x){
    // instanceof instead of internal slot check because we should fix it without replacement native Promise core
    if(x instanceof $Promise && sameConstructor(x.constructor, this))return x;
    var capability = newPromiseCapability(this)
      , $$resolve  = capability.resolve;
    $$resolve(x);
    return capability.promise;
  }
});
$export($export.S + $export.F * !(USE_NATIVE && __webpack_require__("dY0y")(function(iter){
  $Promise.all(iter)['catch'](empty);
})), PROMISE, {
  // 25.4.4.1 Promise.all(iterable)
  all: function all(iterable){
    var C          = this
      , capability = newPromiseCapability(C)
      , resolve    = capability.resolve
      , reject     = capability.reject;
    var abrupt = perform(function(){
      var values    = []
        , index     = 0
        , remaining = 1;
      forOf(iterable, false, function(promise){
        var $index        = index++
          , alreadyCalled = false;
        values.push(undefined);
        remaining++;
        C.resolve(promise).then(function(value){
          if(alreadyCalled)return;
          alreadyCalled  = true;
          values[$index] = value;
          --remaining || resolve(values);
        }, reject);
      });
      --remaining || resolve(values);
    });
    if(abrupt)reject(abrupt.error);
    return capability.promise;
  },
  // 25.4.4.4 Promise.race(iterable)
  race: function race(iterable){
    var C          = this
      , capability = newPromiseCapability(C)
      , reject     = capability.reject;
    var abrupt = perform(function(){
      forOf(iterable, false, function(promise){
        C.resolve(promise).then(capability.resolve, reject);
      });
    });
    if(abrupt)reject(abrupt.error);
    return capability.promise;
  }
});

/***/ }),

/***/ "Cdx3":
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 Object.keys(O)
var toObject = __webpack_require__("sB3e")
  , $keys    = __webpack_require__("lktj");

__webpack_require__("uqUo")('keys', function(){
  return function keys(it){
    return $keys(toObject(it));
  };
});

/***/ }),

/***/ "FIGo":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _classCallCheck2 = __webpack_require__("Zrlr");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _keys = __webpack_require__("fZjL");

var _keys2 = _interopRequireDefault(_keys);

var _getIterator2 = __webpack_require__("BO1k");

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _promise = __webpack_require__("//Fk");

var _promise2 = _interopRequireDefault(_promise);

var _TrelloParsers = __webpack_require__("ZMfs");

var TrelloParsers = _interopRequireWildcard(_TrelloParsers);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var trelloCardFields = ['idList', 'idBoard', 'id', 'name', 'url', 'idMembers', 'subscribed', 'desc'];

var trelloListCardFields = ['idBoard', 'id', 'name', 'url', 'idMembers', 'subscribed', 'desc'];

var trelloBoardFields = ['id', 'name', 'url'];

var trelloListFields = ['id', 'name'];

var promiseReflect = function promiseReflect(promise) {
  return promise.then(function (value) {
    return { value: value, status: 'resolved' };
  }, function (error) {
    return { error: error, status: 'rejected' };
  });
};

function buildCardPromise(trelloApiClient, cardId) {
  var executor = function executor(resolve, reject) {
    trelloApiClient.get('/1/cards/' + cardId, { fields: trelloCardFields.join(',') }).then(function (data) {
      return resolve(data);
    }, function (err) {
      reject(err);
    });
  };
  return promiseReflect(new _promise2.default(executor));
}

function buildCardBoardPromise(trelloApiClient, card) {
  var idBoard = card.idBoard;

  var executor = function executor(resolve, reject) {
    trelloApiClient.get('/1/boards/' + idBoard, { fields: trelloBoardFields.join(',') }).then(function (data) {
      return resolve(data);
    }, function (err) {
      return reject(err);
    });
  };
  return promiseReflect(new _promise2.default(executor));
}

function buildCardListPromise(trelloApiClient, card) {
  var idList = card.idList;

  var executor = function executor(resolve, reject) {
    trelloApiClient.get('/1/lists/' + idList, { fields: trelloListFields.join(',') }).then(function (data) {
      return resolve(data);
    }, function (err) {
      return reject(err);
    });
  };
  return promiseReflect(new _promise2.default(executor));
}

function filterResultsByStatus(results, status) {
  var dataKey = status === 'resolved' ? 'value' : 'error';

  var accepted = [];
  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = (0, _getIterator3.default)(results), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var result = _step.value;

      if (result.status === status) {
        accepted.push(result[dataKey]);
      }
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator.return) {
        _iterator.return();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  return accepted;
}

function mergeCard(card, boards, lists) {
  var newCard = { board: null, list: null };
  var idBoard = card.idBoard,
      idList = card.idList;
  var _iteratorNormalCompletion2 = true;
  var _didIteratorError2 = false;
  var _iteratorError2 = undefined;

  try {

    for (var _iterator2 = (0, _getIterator3.default)(boards), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
      var board = _step2.value;

      if (board.id === idBoard) {
        newCard.board = board;
        break;
      }
    }
  } catch (err) {
    _didIteratorError2 = true;
    _iteratorError2 = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion2 && _iterator2.return) {
        _iterator2.return();
      }
    } finally {
      if (_didIteratorError2) {
        throw _iteratorError2;
      }
    }
  }

  var _iteratorNormalCompletion3 = true;
  var _didIteratorError3 = false;
  var _iteratorError3 = undefined;

  try {
    for (var _iterator3 = (0, _getIterator3.default)(lists), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
      var list = _step3.value;

      if (list.id === idList) {
        newCard.list = list;
        break;
      }
    }
  } catch (err) {
    _didIteratorError3 = true;
    _iteratorError3 = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion3 && _iterator3.return) {
        _iterator3.return();
      }
    } finally {
      if (_didIteratorError3) {
        throw _iteratorError3;
      }
    }
  }

  var _iteratorNormalCompletion4 = true;
  var _didIteratorError4 = false;
  var _iteratorError4 = undefined;

  try {
    for (var _iterator4 = (0, _getIterator3.default)((0, _keys2.default)(card)), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
      var key = _step4.value;

      newCard[key] = card[key];
    }
  } catch (err) {
    _didIteratorError4 = true;
    _iteratorError4 = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion4 && _iterator4.return) {
        _iterator4.return();
      }
    } finally {
      if (_didIteratorError4) {
        throw _iteratorError4;
      }
    }
  }

  return newCard;
}

function accumulateCards(accumulator, cards) {
  accumulator.cards = cards;
  return accumulator;
}

function accumulateBoardsAndLists(accumulator, boardsAndLists) {
  var boards = [];
  var lists = [];

  var _iteratorNormalCompletion5 = true;
  var _didIteratorError5 = false;
  var _iteratorError5 = undefined;

  try {
    for (var _iterator5 = (0, _getIterator3.default)(boardsAndLists), _step5; !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
      var boardOrList = _step5.value;

      if (Object.prototype.hasOwnProperty.call(boardOrList, 'url')) {
        boards.push(boardOrList);
      } else {
        lists.push(boardOrList);
      }
    }
  } catch (err) {
    _didIteratorError5 = true;
    _iteratorError5 = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion5 && _iterator5.return) {
        _iterator5.return();
      }
    } finally {
      if (_didIteratorError5) {
        throw _iteratorError5;
      }
    }
  }

  accumulator.boards = boards;
  accumulator.lists = lists;
  return accumulator;
}

var TrelloClient = function TrelloClient() {
  var _this = this;

  (0, _classCallCheck3.default)(this, TrelloClient);

  this.setApiClient = function (trelloApiClient) {
    _this.trelloApiClient = trelloApiClient;
  };

  this.getCardList = function (cardIdList) {

    if (!cardIdList || !cardIdList.length) {
      return _promise2.default.resolve([]);
    }

    var trelloApiClient = _this.trelloApiClient;

    var cardListData = { cards: null, boards: null, lists: null };

    return _promise2.default.all(cardIdList.map(function (cardId) {
      return buildCardPromise(trelloApiClient, cardId);
    })).then(function (results) {
      return filterResultsByStatus(results, 'resolved');
    }).then(function (cards) {
      return accumulateCards(cardListData, cards);
    }).then(function (accumulator) {
      return _promise2.default.all(accumulator.cards.map(function (card) {
        return buildCardBoardPromise(trelloApiClient, card);
      }).concat(accumulator.cards.map(function (card) {
        return buildCardListPromise(trelloApiClient, card);
      })));
    }).then(function (results) {
      return filterResultsByStatus(results, 'resolved');
    }).then(function (boardsAndLists) {
      return accumulateBoardsAndLists(cardListData, boardsAndLists);
    }).then(function (accumulator) {
      var cards = accumulator.cards,
          boards = accumulator.boards,
          lists = accumulator.lists;

      return cards.map(function (card) {
        return mergeCard(card, boards, lists);
      });
    }).then(function (cards) {
      return cards.map(TrelloParsers.parseTrelloCardJS);
    });
  };

  this.getBoards = function () {
    var trelloApiClient = _this.trelloApiClient;

    var args = { fields: trelloBoardFields.join(',') };

    return trelloApiClient.get('/1/members/me/boards', args).then(function (boards) {
      return boards.map(TrelloParsers.parseTrelloBoardJS);
    });
  };

  this.getBoardLists = function (boardId) {
    var trelloApiClient = _this.trelloApiClient;

    var args = { fields: trelloListFields.join(',') };

    return trelloApiClient.get('/1/boards/' + boardId + '/lists', args).then(function (boards) {
      return boards.map(TrelloParsers.parseTrelloListJS);
    });
  };

  this.getListCards = function (listId) {
    var trelloApiClient = _this.trelloApiClient;

    var args = { fields: trelloListCardFields.join(',') };

    return trelloApiClient.get('/1/lists/' + listId + '/cards', args).then(function (cards) {
      return cards.map(TrelloParsers.parseTrelloCardJS);
    });
  };

  this.createCard = function (card) {
    var list = card.list;

    if (!list || !list.id) {
      throw new Error('missing id from the list');
    }
    var apiRepresentation = TrelloParsers.trelloCardToJS(card);
    var trelloApiClient = _this.trelloApiClient;


    return trelloApiClient.post('/1/cards', apiRepresentation).then(function (data) {
      return TrelloParsers.parseTrelloCardJS(data);
    });
  };

  this.searchCards = function (query) {
    var trelloApiClient = _this.trelloApiClient;

    var args = { query: query, card_fields: 'id', cards_limit: 25, modelTypes: 'cards' };
    return trelloApiClient.get('/1/search', args).then(function (data) {
      return data.cards.map(function (card) {
        return card.id;
      });
    }).then(function (idList) {
      return _this.getCardList(idList);
    });
  };
}

/**
 * @param {TrelloApiClient} trelloApiClient
 */


/**
 * @param {Array<String>} cardIdList
 * @return {Promise}
 */


/**
 * @param {TrelloCard} card
 */
;

exports.default = TrelloClient;

/***/ }),

/***/ "GACX":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _deskproappsSdkReact = __webpack_require__(1);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var AuthenticationRequiredPage = function AuthenticationRequiredPage(_ref) {
  var onAuthenticate = _ref.onAuthenticate;
  return _react2.default.createElement(
    _deskproappsSdkReact.Layout.Section,
    null,
    _react2.default.createElement(
      'p',
      null,
      'Sign into your Trello account to get started:'
    ),
    _react2.default.createElement(
      _deskproappsSdkReact.Layout.Button,
      { primary: true, onClick: onAuthenticate },
      'Login with Trello'
    )
  );
};

AuthenticationRequiredPage.propTypes = {
  onAuthenticate: _react2.default.PropTypes.func.isRequired
};
exports.default = AuthenticationRequiredPage;

/***/ }),

/***/ "HNHs":
/***/ (function(module, exports) {

/* The following list is defined in React's core */
var IS_UNITLESS = {
  animationIterationCount: true,
  boxFlex: true,
  boxFlexGroup: true,
  boxOrdinalGroup: true,
  columnCount: true,
  flex: true,
  flexGrow: true,
  flexPositive: true,
  flexShrink: true,
  flexNegative: true,
  flexOrder: true,
  gridRow: true,
  gridColumn: true,
  fontWeight: true,
  lineClamp: true,
  lineHeight: true,
  opacity: true,
  order: true,
  orphans: true,
  tabSize: true,
  widows: true,
  zIndex: true,
  zoom: true,

  // SVG-related properties
  fillOpacity: true,
  stopOpacity: true,
  strokeDashoffset: true,
  strokeOpacity: true,
  strokeWidth: true
};

module.exports = function(name, value) {
  if(typeof value === 'number' && !IS_UNITLESS[ name ]) {
    return value + 'px';
  } else {
    return value;
  }
};

/***/ }),

/***/ "Ie6m":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {/**
 * Copyright 2013-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 */



if (process.env.NODE_ENV !== 'production') {
  var invariant = __webpack_require__("cxPT");
  var warning = __webpack_require__("YyeZ");
  var ReactPropTypesSecret = __webpack_require__("gt/O");
  var loggedTypeFailures = {};
}

/**
 * Assert that the values match with the type specs.
 * Error messages are memorized and will only be shown once.
 *
 * @param {object} typeSpecs Map of name to a ReactPropType
 * @param {object} values Runtime values that need to be type-checked
 * @param {string} location e.g. "prop", "context", "child context"
 * @param {string} componentName Name of the component for error messages.
 * @param {?Function} getStack Returns the component stack.
 * @private
 */
function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
  if (process.env.NODE_ENV !== 'production') {
    for (var typeSpecName in typeSpecs) {
      if (typeSpecs.hasOwnProperty(typeSpecName)) {
        var error;
        // Prop type validation may throw. In case they do, we don't want to
        // fail the render phase where it didn't fail before. So we log it.
        // After these have been cleaned up, we'll let them throw.
        try {
          // This is intentionally an invariant that gets caught. It's the same
          // behavior as without this statement except with a better message.
          invariant(typeof typeSpecs[typeSpecName] === 'function', '%s: %s type `%s` is invalid; it must be a function, usually from ' + 'React.PropTypes.', componentName || 'React class', location, typeSpecName);
          error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
        } catch (ex) {
          error = ex;
        }
        warning(!error || error instanceof Error, '%s: type specification of %s `%s` is invalid; the type checker ' + 'function must return `null` or an `Error` but returned a %s. ' + 'You may have forgotten to pass an argument to the type checker ' + 'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' + 'shape all require an argument).', componentName || 'React class', location, typeSpecName, typeof error);
        if (error instanceof Error && !(error.message in loggedTypeFailures)) {
          // Only monitor this failure once because there tends to be a lot of the
          // same error.
          loggedTypeFailures[error.message] = true;

          var stack = getStack ? getStack() : '';

          warning(false, 'Failed %s type: %s%s', location, error.message, stack != null ? stack : '');
        }
      }
    }
  }
}

module.exports = checkPropTypes;

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__("b2lT")))

/***/ }),

/***/ "J1NI":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.renderViewDefault = renderViewDefault;
exports.renderTrackHorizontalDefault = renderTrackHorizontalDefault;
exports.renderTrackVerticalDefault = renderTrackVerticalDefault;
exports.renderThumbHorizontalDefault = renderThumbHorizontalDefault;
exports.renderThumbVerticalDefault = renderThumbVerticalDefault;

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

/* eslint-disable react/prop-types */

function renderViewDefault(props) {
    return _react2["default"].createElement('div', props);
}

function renderTrackHorizontalDefault(_ref) {
    var style = _ref.style,
        props = _objectWithoutProperties(_ref, ['style']);

    var finalStyle = _extends({}, style, {
        right: 2,
        bottom: 2,
        left: 2,
        borderRadius: 3
    });
    return _react2["default"].createElement('div', _extends({ style: finalStyle }, props));
}

function renderTrackVerticalDefault(_ref2) {
    var style = _ref2.style,
        props = _objectWithoutProperties(_ref2, ['style']);

    var finalStyle = _extends({}, style, {
        right: 2,
        bottom: 2,
        top: 2,
        borderRadius: 3
    });
    return _react2["default"].createElement('div', _extends({ style: finalStyle }, props));
}

function renderThumbHorizontalDefault(_ref3) {
    var style = _ref3.style,
        props = _objectWithoutProperties(_ref3, ['style']);

    var finalStyle = _extends({}, style, {
        cursor: 'pointer',
        borderRadius: 'inherit',
        backgroundColor: 'rgba(0,0,0,.2)'
    });
    return _react2["default"].createElement('div', _extends({ style: finalStyle }, props));
}

function renderThumbVerticalDefault(_ref4) {
    var style = _ref4.style,
        props = _objectWithoutProperties(_ref4, ['style']);

    var finalStyle = _extends({}, style, {
        cursor: 'pointer',
        borderRadius: 'inherit',
        backgroundColor: 'rgba(0,0,0,.2)'
    });
    return _react2["default"].createElement('div', _extends({ style: finalStyle }, props));
}

/***/ }),

/***/ "JtmH":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {/**
 * Copyright 2013-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 */



var emptyFunction = __webpack_require__("e6+Q");
var invariant = __webpack_require__("cxPT");
var warning = __webpack_require__("YyeZ");

var ReactPropTypesSecret = __webpack_require__("gt/O");
var checkPropTypes = __webpack_require__("Ie6m");

module.exports = function(isValidElement, throwOnDirectAccess) {
  /* global Symbol */
  var ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
  var FAUX_ITERATOR_SYMBOL = '@@iterator'; // Before Symbol spec.

  /**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */
  function getIteratorFn(maybeIterable) {
    var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
    if (typeof iteratorFn === 'function') {
      return iteratorFn;
    }
  }

  /**
   * Collection of methods that allow declaration and validation of props that are
   * supplied to React components. Example usage:
   *
   *   var Props = require('ReactPropTypes');
   *   var MyArticle = React.createClass({
   *     propTypes: {
   *       // An optional string prop named "description".
   *       description: Props.string,
   *
   *       // A required enum prop named "category".
   *       category: Props.oneOf(['News','Photos']).isRequired,
   *
   *       // A prop named "dialog" that requires an instance of Dialog.
   *       dialog: Props.instanceOf(Dialog).isRequired
   *     },
   *     render: function() { ... }
   *   });
   *
   * A more formal specification of how these methods are used:
   *
   *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
   *   decl := ReactPropTypes.{type}(.isRequired)?
   *
   * Each and every declaration produces a function with the same signature. This
   * allows the creation of custom validation functions. For example:
   *
   *  var MyLink = React.createClass({
   *    propTypes: {
   *      // An optional string or URI prop named "href".
   *      href: function(props, propName, componentName) {
   *        var propValue = props[propName];
   *        if (propValue != null && typeof propValue !== 'string' &&
   *            !(propValue instanceof URI)) {
   *          return new Error(
   *            'Expected a string or an URI for ' + propName + ' in ' +
   *            componentName
   *          );
   *        }
   *      }
   *    },
   *    render: function() {...}
   *  });
   *
   * @internal
   */

  var ANONYMOUS = '<<anonymous>>';

  // Important!
  // Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
  var ReactPropTypes = {
    array: createPrimitiveTypeChecker('array'),
    bool: createPrimitiveTypeChecker('boolean'),
    func: createPrimitiveTypeChecker('function'),
    number: createPrimitiveTypeChecker('number'),
    object: createPrimitiveTypeChecker('object'),
    string: createPrimitiveTypeChecker('string'),
    symbol: createPrimitiveTypeChecker('symbol'),

    any: createAnyTypeChecker(),
    arrayOf: createArrayOfTypeChecker,
    element: createElementTypeChecker(),
    instanceOf: createInstanceTypeChecker,
    node: createNodeChecker(),
    objectOf: createObjectOfTypeChecker,
    oneOf: createEnumTypeChecker,
    oneOfType: createUnionTypeChecker,
    shape: createShapeTypeChecker
  };

  /**
   * inlined Object.is polyfill to avoid requiring consumers ship their own
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
   */
  /*eslint-disable no-self-compare*/
  function is(x, y) {
    // SameValue algorithm
    if (x === y) {
      // Steps 1-5, 7-10
      // Steps 6.b-6.e: +0 != -0
      return x !== 0 || 1 / x === 1 / y;
    } else {
      // Step 6.a: NaN == NaN
      return x !== x && y !== y;
    }
  }
  /*eslint-enable no-self-compare*/

  /**
   * We use an Error-like object for backward compatibility as people may call
   * PropTypes directly and inspect their output. However, we don't use real
   * Errors anymore. We don't inspect their stack anyway, and creating them
   * is prohibitively expensive if they are created too often, such as what
   * happens in oneOfType() for any type before the one that matched.
   */
  function PropTypeError(message) {
    this.message = message;
    this.stack = '';
  }
  // Make `instanceof Error` still work for returned errors.
  PropTypeError.prototype = Error.prototype;

  function createChainableTypeChecker(validate) {
    if (process.env.NODE_ENV !== 'production') {
      var manualPropTypeCallCache = {};
      var manualPropTypeWarningCount = 0;
    }
    function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
      componentName = componentName || ANONYMOUS;
      propFullName = propFullName || propName;

      if (secret !== ReactPropTypesSecret) {
        if (throwOnDirectAccess) {
          // New behavior only for users of `prop-types` package
          invariant(
            false,
            'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
            'Use `PropTypes.checkPropTypes()` to call them. ' +
            'Read more at http://fb.me/use-check-prop-types'
          );
        } else if (process.env.NODE_ENV !== 'production' && typeof console !== 'undefined') {
          // Old behavior for people using React.PropTypes
          var cacheKey = componentName + ':' + propName;
          if (
            !manualPropTypeCallCache[cacheKey] &&
            // Avoid spamming the console because they are often not actionable except for lib authors
            manualPropTypeWarningCount < 3
          ) {
            warning(
              false,
              'You are manually calling a React.PropTypes validation ' +
              'function for the `%s` prop on `%s`. This is deprecated ' +
              'and will throw in the standalone `prop-types` package. ' +
              'You may be seeing this warning due to a third-party PropTypes ' +
              'library. See https://fb.me/react-warning-dont-call-proptypes ' + 'for details.',
              propFullName,
              componentName
            );
            manualPropTypeCallCache[cacheKey] = true;
            manualPropTypeWarningCount++;
          }
        }
      }
      if (props[propName] == null) {
        if (isRequired) {
          if (props[propName] === null) {
            return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required ' + ('in `' + componentName + '`, but its value is `null`.'));
          }
          return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required in ' + ('`' + componentName + '`, but its value is `undefined`.'));
        }
        return null;
      } else {
        return validate(props, propName, componentName, location, propFullName);
      }
    }

    var chainedCheckType = checkType.bind(null, false);
    chainedCheckType.isRequired = checkType.bind(null, true);

    return chainedCheckType;
  }

  function createPrimitiveTypeChecker(expectedType) {
    function validate(props, propName, componentName, location, propFullName, secret) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== expectedType) {
        // `propValue` being instance of, say, date/regexp, pass the 'object'
        // check, but we can offer a more precise error message here rather than
        // 'of type `object`'.
        var preciseType = getPreciseType(propValue);

        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + preciseType + '` supplied to `' + componentName + '`, expected ') + ('`' + expectedType + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createAnyTypeChecker() {
    return createChainableTypeChecker(emptyFunction.thatReturnsNull);
  }

  function createArrayOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside arrayOf.');
      }
      var propValue = props[propName];
      if (!Array.isArray(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an array.'));
      }
      for (var i = 0; i < propValue.length; i++) {
        var error = typeChecker(propValue, i, componentName, location, propFullName + '[' + i + ']', ReactPropTypesSecret);
        if (error instanceof Error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createElementTypeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      if (!isValidElement(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createInstanceTypeChecker(expectedClass) {
    function validate(props, propName, componentName, location, propFullName) {
      if (!(props[propName] instanceof expectedClass)) {
        var expectedClassName = expectedClass.name || ANONYMOUS;
        var actualClassName = getClassName(props[propName]);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + actualClassName + '` supplied to `' + componentName + '`, expected ') + ('instance of `' + expectedClassName + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createEnumTypeChecker(expectedValues) {
    if (!Array.isArray(expectedValues)) {
      process.env.NODE_ENV !== 'production' ? warning(false, 'Invalid argument supplied to oneOf, expected an instance of array.') : void 0;
      return emptyFunction.thatReturnsNull;
    }

    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      for (var i = 0; i < expectedValues.length; i++) {
        if (is(propValue, expectedValues[i])) {
          return null;
        }
      }

      var valuesString = JSON.stringify(expectedValues);
      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of value `' + propValue + '` ' + ('supplied to `' + componentName + '`, expected one of ' + valuesString + '.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createObjectOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside objectOf.');
      }
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an object.'));
      }
      for (var key in propValue) {
        if (propValue.hasOwnProperty(key)) {
          var error = typeChecker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
          if (error instanceof Error) {
            return error;
          }
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createUnionTypeChecker(arrayOfTypeCheckers) {
    if (!Array.isArray(arrayOfTypeCheckers)) {
      process.env.NODE_ENV !== 'production' ? warning(false, 'Invalid argument supplied to oneOfType, expected an instance of array.') : void 0;
      return emptyFunction.thatReturnsNull;
    }

    for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
      var checker = arrayOfTypeCheckers[i];
      if (typeof checker !== 'function') {
        warning(
          false,
          'Invalid argument supplid to oneOfType. Expected an array of check functions, but ' +
          'received %s at index %s.',
          getPostfixForTypeWarning(checker),
          i
        );
        return emptyFunction.thatReturnsNull;
      }
    }

    function validate(props, propName, componentName, location, propFullName) {
      for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
        var checker = arrayOfTypeCheckers[i];
        if (checker(props, propName, componentName, location, propFullName, ReactPropTypesSecret) == null) {
          return null;
        }
      }

      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createNodeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      if (!isNode(props[propName])) {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`, expected a ReactNode.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      for (var key in shapeTypes) {
        var checker = shapeTypes[key];
        if (!checker) {
          continue;
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function isNode(propValue) {
    switch (typeof propValue) {
      case 'number':
      case 'string':
      case 'undefined':
        return true;
      case 'boolean':
        return !propValue;
      case 'object':
        if (Array.isArray(propValue)) {
          return propValue.every(isNode);
        }
        if (propValue === null || isValidElement(propValue)) {
          return true;
        }

        var iteratorFn = getIteratorFn(propValue);
        if (iteratorFn) {
          var iterator = iteratorFn.call(propValue);
          var step;
          if (iteratorFn !== propValue.entries) {
            while (!(step = iterator.next()).done) {
              if (!isNode(step.value)) {
                return false;
              }
            }
          } else {
            // Iterator will provide entry [k,v] tuples rather than values.
            while (!(step = iterator.next()).done) {
              var entry = step.value;
              if (entry) {
                if (!isNode(entry[1])) {
                  return false;
                }
              }
            }
          }
        } else {
          return false;
        }

        return true;
      default:
        return false;
    }
  }

  function isSymbol(propType, propValue) {
    // Native Symbol.
    if (propType === 'symbol') {
      return true;
    }

    // 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
    if (propValue['@@toStringTag'] === 'Symbol') {
      return true;
    }

    // Fallback for non-spec compliant Symbols which are polyfilled.
    if (typeof Symbol === 'function' && propValue instanceof Symbol) {
      return true;
    }

    return false;
  }

  // Equivalent of `typeof` but with special handling for array and regexp.
  function getPropType(propValue) {
    var propType = typeof propValue;
    if (Array.isArray(propValue)) {
      return 'array';
    }
    if (propValue instanceof RegExp) {
      // Old webkits (at least until Android 4.0) return 'function' rather than
      // 'object' for typeof a RegExp. We'll normalize this here so that /bla/
      // passes PropTypes.object.
      return 'object';
    }
    if (isSymbol(propType, propValue)) {
      return 'symbol';
    }
    return propType;
  }

  // This handles more types than `getPropType`. Only used for error messages.
  // See `createPrimitiveTypeChecker`.
  function getPreciseType(propValue) {
    if (typeof propValue === 'undefined' || propValue === null) {
      return '' + propValue;
    }
    var propType = getPropType(propValue);
    if (propType === 'object') {
      if (propValue instanceof Date) {
        return 'date';
      } else if (propValue instanceof RegExp) {
        return 'regexp';
      }
    }
    return propType;
  }

  // Returns a string that is postfixed to a warning about an invalid type.
  // For example, "undefined" or "of type array"
  function getPostfixForTypeWarning(value) {
    var type = getPreciseType(value);
    switch (type) {
      case 'array':
      case 'object':
        return 'an ' + type;
      case 'boolean':
      case 'date':
      case 'regexp':
        return 'a ' + type;
      default:
        return type;
    }
  }

  // Returns class name of the object, if any.
  function getClassName(propValue) {
    if (!propValue.constructor || !propValue.constructor.name) {
      return ANONYMOUS;
    }
    return propValue.constructor.name;
  }

  ReactPropTypes.checkPropTypes = checkPropTypes;
  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__("b2lT")))

/***/ }),

/***/ "KSGD":
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(process) {/**
 * Copyright 2013-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 */

if (process.env.NODE_ENV !== 'production') {
  var REACT_ELEMENT_TYPE = (typeof Symbol === 'function' &&
    Symbol.for &&
    Symbol.for('react.element')) ||
    0xeac7;

  var isValidElement = function(object) {
    return typeof object === 'object' &&
      object !== null &&
      object.$$typeof === REACT_ELEMENT_TYPE;
  };

  // By explicitly using `prop-types` you are opting into new development behavior.
  // http://fb.me/prop-types-in-prod
  var throwOnDirectAccess = true;
  module.exports = __webpack_require__("JtmH")(isValidElement, throwOnDirectAccess);
} else {
  // By explicitly using `prop-types` you are opting into new production behavior.
  // http://fb.me/prop-types-in-prod
  module.exports = __webpack_require__("Q4WQ")();
}

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__("b2lT")))

/***/ }),

/***/ "L42u":
/***/ (function(module, exports, __webpack_require__) {

var ctx                = __webpack_require__("+ZMJ")
  , invoke             = __webpack_require__("knuC")
  , html               = __webpack_require__("RPLV")
  , cel                = __webpack_require__("ON07")
  , global             = __webpack_require__("7KvD")
  , process            = global.process
  , setTask            = global.setImmediate
  , clearTask          = global.clearImmediate
  , MessageChannel     = global.MessageChannel
  , counter            = 0
  , queue              = {}
  , ONREADYSTATECHANGE = 'onreadystatechange'
  , defer, channel, port;
var run = function(){
  var id = +this;
  if(queue.hasOwnProperty(id)){
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var listener = function(event){
  run.call(event.data);
};
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if(!setTask || !clearTask){
  setTask = function setImmediate(fn){
    var args = [], i = 1;
    while(arguments.length > i)args.push(arguments[i++]);
    queue[++counter] = function(){
      invoke(typeof fn == 'function' ? fn : Function(fn), args);
    };
    defer(counter);
    return counter;
  };
  clearTask = function clearImmediate(id){
    delete queue[id];
  };
  // Node.js 0.8-
  if(__webpack_require__("R9M2")(process) == 'process'){
    defer = function(id){
      process.nextTick(ctx(run, id, 1));
    };
  // Browsers with MessageChannel, includes WebWorkers
  } else if(MessageChannel){
    channel = new MessageChannel;
    port    = channel.port2;
    channel.port1.onmessage = listener;
    defer = ctx(port.postMessage, port, 1);
  // Browsers with postMessage, skip WebWorkers
  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if(global.addEventListener && typeof postMessage == 'function' && !global.importScripts){
    defer = function(id){
      global.postMessage(id + '', '*');
    };
    global.addEventListener('message', listener, false);
  // IE8-
  } else if(ONREADYSTATECHANGE in cel('script')){
    defer = function(id){
      html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function(){
        html.removeChild(this);
        run.call(id);
      };
    };
  // Rest old browsers
  } else {
    defer = function(id){
      setTimeout(ctx(run, id, 1), 0);
    };
  }
}
module.exports = {
  set:   setTask,
  clear: clearTask
};

/***/ }),

/***/ "LTvc":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _assign = __webpack_require__("woOf");

var _assign2 = _interopRequireDefault(_assign);

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _promise = __webpack_require__("//Fk");

var _promise2 = _interopRequireDefault(_promise);

var _getPrototypeOf = __webpack_require__("Zx67");

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__("Zrlr");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__("wxAW");

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__("zwoO");

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__("Pf15");

var _inherits3 = _interopRequireDefault(_inherits2);

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _TrelloParsers = __webpack_require__("ZMfs");

var TrellParsers = _interopRequireWildcard(_TrelloParsers);

var _Trello = __webpack_require__("royy");

var _AuthenticationRequiredError = __webpack_require__("AlEQ");

var _AuthenticationRequiredError2 = _interopRequireDefault(_AuthenticationRequiredError);

var _UI = __webpack_require__("t2//");

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var TrelloApp = function (_React$Component) {
  (0, _inherits3.default)(TrelloApp, _React$Component);

  function TrelloApp(props) {
    (0, _classCallCheck3.default)(this, TrelloApp);

    var _this = (0, _possibleConstructorReturn3.default)(this, (TrelloApp.__proto__ || (0, _getPrototypeOf2.default)(TrelloApp)).call(this, props));

    _initialiseProps.call(_this);

    _this.initUiState = '';

    var key = '32388eb417f0326c4d75ab77c2a5d7e7';
    _this.trelloApiClient = new _Trello.TrelloApiClient(key);
    _this.trelloClient = new _Trello.TrelloClient();

    _this.initState();
    return _this;
  }

  (0, _createClass3.default)(TrelloApp, [{
    key: 'shouldComponentUpdate',
    value: function shouldComponentUpdate(nextProps, nextState) {
      return this.state.uiState != nextState.uiState || this.state.authorizedUIState !== nextState.authorizedUIState || this.state.stateTransitionsCount !== nextState.stateTransitionsCount || this.state.refreshCount !== nextState.refreshCount;
    }
  }, {
    key: 'componentDidMount',
    value: function componentDidMount() {
      var _this2 = this;

      var dpapp = this.props.dpapp;
      var ticketId = this.state.ticketState.ticketId;


      dpapp.on('app.refresh', function () {
        _this2.sameUIStateTransition(_promise2.default.resolve({ refreshCount: _this2.state.refreshCount + 1 }));
      });

      dpapp.on('ui.show-settings', this.onSettings);
      dpapp.ui.showLoading();
      dpapp.ui.hideMenu();

      var appState = this.props.dpapp.appState;


      appState.asyncGetPrivate('auth').then(function (state) {
        return _this2.onExistingAuthStateReceived(state);
      }).then(function () {
        return _this2.retrieveTicketState(ticketId);
      }).catch(function (err) {
        if (err instanceof _AuthenticationRequiredError2.default) {
          _this2.setState({ uiState: 'authentication-required' });
        }
        return err;
      }).then(function (mixed) {
        dpapp.ui.hideLoading();
        return mixed;
      }).then(function (mixed) {
        if (mixed instanceof Error) {
          throw mixed;
        }
        return mixed;
      });
    }

    /**
     * @param card
     * @return {Promise.<{ticketState: {trello_cards: Array.<*>}}>}
     */


    /**
     * @param {TrelloCard} card
     */


    /**
     * @param {TrelloCard} card
     */


    /**
     * @param {TrelloCard} card
     */


    /**
     * @param nextState
     * @param {Promise} transition
     */

  }, {
    key: 'render',
    value: function render() {
      var uiState = this.state.uiState;


      switch (uiState) {
        case 'authentication-required':
          return this.renderAuthenticationRequired();
        case 'create-card':
          return this.renderCreateCard();
        case 'pick-card':
          return this.renderPickCard();
        case 'search-card':
          return this.renderSearchCard();
        case 'ticket-loaded':
          return this.renderTicketLoaded();
        default:
          return null;
      }
    }
  }]);
  return TrelloApp;
}(_react2.default.Component);

TrelloApp.propTypes = { dpapp: _react2.default.PropTypes.object.isRequired };

var _initialiseProps = function _initialiseProps() {
  var _this3 = this;

  this.initState = function () {
    var ticketId = _this3.props.dpapp.context.entityId;


    _this3.state = {
      authUser: null,
      authState: null,
      authorizedUIState: null,
      cards: null,
      boards: [],
      lists: [],

      stateTransitionsCount: 0,
      ticketState: { ticketId: ticketId, trello_cards: [] },

      uiState: _this3.initUiState,

      createCardModel: null,
      pickCardModel: null,

      refreshCount: 0
    };
  };

  this.onSettings = function () {
    alert('on settings clicked');
  };

  this.onExistingAuthStateReceived = function (authState) {
    var dpapp = _this3.props.dpapp;
    var trelloApiClient = _this3.trelloApiClient,
        trelloClient = _this3.trelloClient;


    if (authState) {
      trelloApiClient.setToken(authState);
      return _this3.verifyTrelloAuthentication().then(function (data) {
        trelloClient.setApiClient(trelloApiClient);
        _this3.setState({ authState: authState, authUser: data });
        dpapp.ui.showMenu();
        return data;
      });
    }
  };

  this.onNewAuthStateReceived = function (authState) {
    var trelloApiClient = _this3.trelloApiClient,
        trelloClient = _this3.trelloClient;


    if (authState) {
      var authorizedUIState = _this3.state.authorizedUIState;

      trelloApiClient.setToken(authState);
      trelloClient.setApiClient(trelloApiClient);

      var _props$dpapp = _this3.props.dpapp,
          appState = _props$dpapp.appState,
          ui = _props$dpapp.ui;


      return _this3.retrieveTrelloAuthUser().then(function (data) {
        return appState.asyncSetPrivate('auth', authState).then(function () {
          return data;
        });
      }).then(function (data) {
        _this3.setState({ authState: authState, authUser: data, uiState: authorizedUIState });
        ui.showMenu();
        return authState;
      });
    }
  };

  this.onTicketStateReceived = function (newTicketState) {
    var uiState = _this3.getInitialUIState();
    var ticketState = newTicketState || _this3.state.ticketState; // TODO Must not overwrite state blindly like this !!!

    _this3.trelloClient.getCardList(ticketState.trello_cards).then(function (linkedCards) {
      return _this3.setState((0, _extends3.default)({}, uiState, { ticketState: ticketState, linkedCards: linkedCards }));
    });
  };

  this.onLinkTrelloCard = function (card) {
    var _state = _this3.state,
        ticketState = _state.ticketState,
        linkedCards = _state.linkedCards;
    var ticketId = _this3.state.ticketState.ticketId;


    if (linkedCards.filter(function (linkedCard) {
      return linkedCard.id === card.id;
    }).length) {
      return _promise2.default.resolve({ ticketState: ticketState, linkedCards: linkedCards });
    }

    var newTicketState = (0, _assign2.default)({}, ticketState, { trello_cards: [card.id].concat(ticketState.trello_cards) });
    var newLinkedCards = [card].concat(linkedCards);

    var appState = _this3.props.dpapp.appState;


    return appState.asyncSetShared(ticketId, newTicketState).then(function () {
      return { ticketState: newTicketState, linkedCards: newLinkedCards };
    });
  };

  this.onCreateAndLinkTrelloCard = function (card) {
    var trelloClient = _this3.trelloClient;

    return trelloClient.createCard(card).then(function (newCard) {
      return _this3.onLinkTrelloCard(newCard);
    });
  };

  this.onUnlinkTrelloCard = function (card) {
    var _state2 = _this3.state,
        ticketState = _state2.ticketState,
        linkedCards = _state2.linkedCards;
    var ticketId = _this3.state.ticketState.ticketId;


    var newLinkedCards = linkedCards.filter(function (linkedCard) {
      return linkedCard.id !== card.id;
    });
    if (newLinkedCards.length === linkedCards.length) {
      // card is not a previously linked card
      return _promise2.default.resolve({});
    }
    var newTicketState = (0, _assign2.default)({}, ticketState, { trello_cards: newLinkedCards.map(function (linkedCard) {
        return linkedCard.id;
      }) });

    var appState = _this3.props.dpapp.appState;


    return appState.asyncSetShared(ticketId, newTicketState).then(function () {
      return { ticketState: newTicketState, linkedCards: newLinkedCards };
    });
  };

  this.onGoToTrelloCard = function (card) {
    window.open(card.url, '_blank');
  };

  this.getInitialUIState = function () {
    var authState = _this3.state.authState;

    var authorizedUIState = 'ticket-loaded';
    var uiState = authState ? authorizedUIState : 'authentication-required';

    return { authorizedUIState: authorizedUIState, uiState: uiState };
  };

  this.onAuthenticate = function () {
    var authOptions = {
      expiration: 'never',
      interactive: true,
      name: 'Deskpro',
      persist: false,
      scope: {
        read: true,
        write: true
      },
      type: 'popup'
    };
    var dpapp = _this3.props.dpapp;
    var trelloApiClient = _this3.trelloApiClient;
    var ticketId = _this3.state.ticketState.ticketId;


    trelloApiClient.auth(authOptions).then(function () {
      return trelloApiClient.token;
    }).then(function (token) {
      return _this3.onNewAuthStateReceived(token);
    }).then(function () {
      return _this3.retrieveTicketState(ticketId);
    }).catch(function (err) {
      console.log('on authenticate error ', err);return err;
    }).then(function (mixed) {
      dpapp.ui.hideLoading();
      return mixed;
    });
  };

  this.verifyTrelloAuthentication = function () {
    var appState = _this3.props.dpapp.appState;


    return _this3.trelloApiClient.get('/1/members/me?fields=username,fullName').catch(function (err) {
      if (err instanceof _Trello.TrelloApiError && err.response.status === 401) {
        return appState.asyncDeletePrivate('auth').then(function () {
          return new _AuthenticationRequiredError2.default('authentication error', err);
        });
      }
      return err;
    }).then(function (mixed) {
      if (mixed instanceof Error) {
        throw mixed;
      }
      return mixed;
    });
  };

  this.retrieveTicketState = function (ticketId) {
    var appState = _this3.props.dpapp.appState;
    // notify dp the app is ready

    return appState.asyncGetShared(ticketId).then(function (state) {
      return _this3.onTicketStateReceived(state);
    });
  };

  this.retrieveTrelloAuthUser = function () {
    return _this3.trelloApiClient.get('/1/members/me?fields=username,fullName');
  };

  this.sameUIStateTransition = function (transition) {
    var uiState = _this3.state.uiState;

    return _this3.nextUIStateTransition(uiState, transition);
  };

  this.nextUIStateTransition = function (nextState, transition) {
    var dpapp = _this3.props.dpapp;
    var stateTransitionsCount = _this3.state.stateTransitionsCount;

    dpapp.ui.showLoading();

    return transition.then(function (value) {
      dpapp.ui.hideLoading();
      _this3.setState((0, _extends3.default)({ stateTransitionsCount: stateTransitionsCount + 1, authorizedUIState: nextState, uiState: nextState }, value));
      return value;
    }, function (error) {
      dpapp.ui.hideLoading();

      return error;
    });
  };

  this.renderAuthenticationRequired = function () {
    return _react2.default.createElement(_UI.AuthenticationRequiredPage, { onAuthenticate: _this3.onAuthenticate });
  };

  this.renderCreateCard = function () {
    var loadBoardLists = _this3.loadBoardLists;
    var _state3 = _this3.state,
        createCardModel = _state3.createCardModel,
        boards = _state3.boards,
        lists = _state3.lists;


    var onCancel = function onCancel() {
      _this3.nextUIStateTransition('ticket-loaded', _promise2.default.resolve({ createCardModel: null, boards: [], lists: [] }));
    };

    var onSubmit = function onSubmit(model) {
      // should be sent somewhere
      _this3.setState({ createCardModel: model });
      var trelloCard = TrellParsers.parseTrelloCardFormJS(model, boards, lists);

      _this3.nextUIStateTransition('ticket-loaded', _this3.onCreateAndLinkTrelloCard(trelloCard).then(function (nextState) {
        return (0, _extends3.default)({}, nextState, { createCardModel: null });
      }));
    };

    var onChange = function onChange(key, value, model) {
      var onChangePromise = void 0;

      if (key === 'board' && value) {
        var executor = function executor(data) {
          var listId = data.lists && data.lists.length ? data.lists[0].id : null;
          return (0, _extends3.default)({}, data, { createCardModel: (0, _extends3.default)({}, model, { list: listId }) });
        };
        onChangePromise = loadBoardLists(value).then(executor);
      }

      if (onChangePromise) {
        _this3.sameUIStateTransition(onChangePromise.then(function (finalState) {
          return finalState;
        }));
      }
    };

    return _react2.default.createElement(
      'div',
      null,
      _react2.default.createElement(_UI.CreateCardSection, {
        onCancel: onCancel,
        onSubmit: onSubmit,
        onChange: onChange,
        model: createCardModel,
        boards: boards,
        lists: lists
      })
    );
  };

  this.loadBoards = function () {
    var trelloClient = _this3.trelloClient;


    var executor = function executor(boards) {
      if (boards.length === 0) {
        return { boards: [], lists: [], cards: [] };
      }

      var id = boards[0].id;

      return _this3.loadBoardLists(id).then(function (data) {
        return (0, _extends3.default)({ boards: boards }, data);
      });
    };

    return trelloClient.getBoards().then(executor);
  };

  this.loadBoardLists = function (boardId) {
    var trelloClient = _this3.trelloClient;


    return trelloClient.getBoardLists(boardId).then(function (lists) {
      if (lists.length === 0) {
        return { lists: [], cards: [] };
      }

      var id = lists[0].id;

      var executor = function executor(data) {
        return (0, _extends3.default)({ lists: lists }, data);
      };

      return _this3.loadListCards(id).then(executor);
    });
  };

  this.loadListCards = function (listId) {
    var trelloClient = _this3.trelloClient;

    var executor = function executor(newCards) {
      return { cards: newCards };
    };

    return trelloClient.getListCards(listId).then(executor);
  };

  this.renderPickCard = function () {
    var _state4 = _this3.state,
        pickCardModel = _state4.pickCardModel,
        boards = _state4.boards,
        lists = _state4.lists,
        cards = _state4.cards;
    var loadBoardLists = _this3.loadBoardLists,
        loadListCards = _this3.loadListCards;


    var onCancel = function onCancel() {
      _this3.nextUIStateTransition('ticket-loaded', _promise2.default.resolve({ pickCardModel: null, cards: null, boards: [], lists: [] }));
    };

    var onChange = function onChange(key, value, model) {
      var onChangePromise = void 0;
      var executor = function executor(data) {
        return (0, _extends3.default)({}, data, { pickCardModel: model });
      };

      if (key === 'board' && value) {
        onChangePromise = loadBoardLists(value).then(executor);
      } else if (key === 'list' && value) {
        onChangePromise = loadListCards(value).then(executor);
      }

      if (onChangePromise) {
        _this3.sameUIStateTransition(onChangePromise.then(function (finalState) {
          return finalState;
        }));
      }
    };

    /**
     * @param {TrelloCard} card
     */
    var onSelectCard = function onSelectCard(card) {
      _this3.nextUIStateTransition('ticket-loaded', _this3.onLinkTrelloCard(card));
    };
    var onGotoCard = _this3.onGoToTrelloCard;

    return _react2.default.createElement(
      'div',
      null,
      _react2.default.createElement(_UI.PickCardSection, {
        onGotoCard: onGotoCard,
        onSelectCard: onSelectCard,
        onCancel: onCancel,
        onChange: onChange,
        model: pickCardModel,
        boards: boards,
        lists: lists,
        cards: cards
      })
    );
  };

  this.renderSearchCard = function () {
    var trelloClient = _this3.trelloClient;
    var cards = _this3.state.cards;


    var onSearchChange = function onSearchChange(query) {
      var parsedCard = (0, _Trello.parseTrelloCardUrl)(query);
      var onSearchPromise = null;

      if (parsedCard) {
        var shortLink = parsedCard.shortLink;

        onSearchPromise = trelloClient.getCardList([shortLink]).then(function (foundCards) {
          return { cards: foundCards };
        });
      } else {
        onSearchPromise = trelloClient.searchCards(query).then(function (foundCards) {
          return { cards: foundCards };
        });
      }

      if (onSearchPromise) {
        _this3.sameUIStateTransition(onSearchPromise);
      }
    };

    var onCancel = function onCancel() {
      _this3.nextUIStateTransition('ticket-loaded', _promise2.default.resolve({ cards: [] }));
    };

    /**
     * @param {TrelloCard} card
     */
    var onSelectCard = function onSelectCard(card) {
      _this3.nextUIStateTransition('ticket-loaded', _this3.onLinkTrelloCard(card));
    };

    var onGotoCard = _this3.onGoToTrelloCard;

    return _react2.default.createElement(
      'div',
      null,
      _react2.default.createElement(_UI.SearchCardSection, {
        cards: cards,
        onGotoCard: onGotoCard,
        onSelectCard: onSelectCard,
        onCancel: onCancel,
        onSearchChange: onSearchChange
      })
    );
  };

  this.renderTicketLoaded = function () {
    var linkedCards = _this3.state.linkedCards;


    var onCreate = function onCreate() {
      _this3.nextUIStateTransition('create-card', _this3.loadBoards());
    };

    var onPick = function onPick() {
      _this3.nextUIStateTransition('pick-card', _this3.loadBoards());
    };

    var onSearch = function onSearch() {
      _this3.nextUIStateTransition('search-card', _promise2.default.resolve({ cards: [] }));
    };

    var onGotoCard = _this3.onGoToTrelloCard;

    /**
     * @param {TrelloCard} card
     */
    var onUnlinkCard = function onUnlinkCard(card) {
      _this3.sameUIStateTransition(_this3.onUnlinkTrelloCard(card));
    };

    return _react2.default.createElement(
      'div',
      null,
      _react2.default.createElement(_UI.LinkedCardsSection, { cards: linkedCards, onSelectCard: onGotoCard, onUnlinkCard: onUnlinkCard }),
      _react2.default.createElement(_UI.LinkToCardSection, { onPick: onPick, onCreate: onCreate, onSearch: onSearch })
    );
  };
};

exports.default = TrelloApp;

/***/ }),

/***/ "MXhf":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _objectWithoutProperties2 = __webpack_require__("+6Bu");

var _objectWithoutProperties3 = _interopRequireDefault(_objectWithoutProperties2);

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _deskproappsSdkReact = __webpack_require__(1);

var _CardListComponent = __webpack_require__("oWNz");

var _CardListComponent2 = _interopRequireDefault(_CardListComponent);

var _SearchInputComponent = __webpack_require__("c0uK");

var _SearchInputComponent2 = _interopRequireDefault(_SearchInputComponent);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var SearchCardSection = function SearchCardSection(_ref) {
  var onSelectCard = _ref.onSelectCard,
      onGotoCard = _ref.onGotoCard,
      onCancel = _ref.onCancel,
      onSearchChange = _ref.onSearchChange,
      cards = _ref.cards,
      otherProps = (0, _objectWithoutProperties3.default)(_ref, ['onSelectCard', 'onGotoCard', 'onCancel', 'onSearchChange', 'cards']);


  return _react2.default.createElement(
    _deskproappsSdkReact.Layout.Section,
    { title: 'SEARCH FOR A CARD' },
    _react2.default.createElement(
      _deskproappsSdkReact.Layout.Block,
      null,
      _react2.default.createElement(_SearchInputComponent2.default, {
        fluid: true,
        placeholder: 'Search card or paste URL...',
        minCharacters: 3,
        onChange: onSearchChange
      })
    ),
    _react2.default.createElement(
      _deskproappsSdkReact.Layout.Block,
      null,
      _react2.default.createElement(_CardListComponent2.default, { cards: cards || [], onSelectCard: onSelectCard, onGotoCard: onGotoCard, showBorder: true })
    ),
    _react2.default.createElement(
      _deskproappsSdkReact.Layout.Block,
      null,
      _react2.default.createElement(
        _deskproappsSdkReact.Layout.Button,
        { onClick: onCancel },
        'Cancel'
      )
    )
  );
};

SearchCardSection.propTypes = {
  cards: _react2.default.PropTypes.array,
  onCancel: _react2.default.PropTypes.func,
  onSearchChange: _react2.default.PropTypes.func,
  onSelectCard: _react2.default.PropTypes.func,
  onGotoCard: _react2.default.PropTypes.func
};

exports.default = SearchCardSection;

/***/ }),

/***/ "MoWu":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
var containerStyleDefault = exports.containerStyleDefault = {
    position: 'relative',
    overflow: 'hidden',
    width: '100%',
    height: '100%'
};

// Overrides containerStyleDefault properties
var containerStyleAutoHeight = exports.containerStyleAutoHeight = {
    height: 'auto'
};

var viewStyleDefault = exports.viewStyleDefault = {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    overflow: 'scroll',
    WebkitOverflowScrolling: 'touch'
};

// Overrides viewStyleDefault properties
var viewStyleAutoHeight = exports.viewStyleAutoHeight = {
    position: 'relative',
    top: undefined,
    left: undefined,
    right: undefined,
    bottom: undefined
};

var viewStyleUniversalInitial = exports.viewStyleUniversalInitial = {
    overflow: 'hidden',
    marginRight: 0,
    marginBottom: 0
};

var trackHorizontalStyleDefault = exports.trackHorizontalStyleDefault = {
    position: 'absolute',
    height: 6
};

var trackVerticalStyleDefault = exports.trackVerticalStyleDefault = {
    position: 'absolute',
    width: 6
};

var thumbHorizontalStyleDefault = exports.thumbHorizontalStyleDefault = {
    position: 'relative',
    display: 'block',
    height: '100%'
};

var thumbVerticalStyleDefault = exports.thumbVerticalStyleDefault = {
    position: 'relative',
    display: 'block',
    width: '100%'
};

var disableSelectStyle = exports.disableSelectStyle = {
    userSelect: 'none'
};

var disableSelectStyleReset = exports.disableSelectStyleReset = {
    userSelect: ''
};

/***/ }),

/***/ "NWt+":
/***/ (function(module, exports, __webpack_require__) {

var ctx         = __webpack_require__("+ZMJ")
  , call        = __webpack_require__("msXi")
  , isArrayIter = __webpack_require__("Mhyx")
  , anObject    = __webpack_require__("77Pl")
  , toLength    = __webpack_require__("QRG4")
  , getIterFn   = __webpack_require__("3fs2")
  , BREAK       = {}
  , RETURN      = {};
var exports = module.exports = function(iterable, entries, fn, that, ITERATOR){
  var iterFn = ITERATOR ? function(){ return iterable; } : getIterFn(iterable)
    , f      = ctx(fn, that, entries ? 2 : 1)
    , index  = 0
    , length, step, iterator, result;
  if(typeof iterFn != 'function')throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if(isArrayIter(iterFn))for(length = toLength(iterable.length); length > index; index++){
    result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
    if(result === BREAK || result === RETURN)return result;
  } else for(iterator = iterFn.call(iterable); !(step = iterator.next()).done; ){
    result = call(iterator, f, step.value, entries);
    if(result === BREAK || result === RETURN)return result;
  }
};
exports.BREAK  = BREAK;
exports.RETURN = RETURN;

/***/ }),

/***/ "PWsu":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports["default"] = returnFalse;
function returnFalse() {
    return false;
}

/***/ }),

/***/ "PqSB":
/***/ (function(module, exports, __webpack_require__) {

var prefix = __webpack_require__("nPmw")
var toCamelCase = __webpack_require__("UTRz")
var cache = { 'float': 'cssFloat' }
var addPxToStyle = __webpack_require__("HNHs")

function style (element, property, value) {
  var camel = cache[property]
  if (typeof camel === 'undefined') {
    camel = detect(property)
  }

  // may be false if CSS prop is unsupported
  if (camel) {
    if (value === undefined) {
      return element.style[camel]
    }

    element.style[camel] = addPxToStyle(camel, value)
  }
}

function each (element, properties) {
  for (var k in properties) {
    if (properties.hasOwnProperty(k)) {
      style(element, k, properties[k])
    }
  }
}

function detect (cssProp) {
  var camel = toCamelCase(cssProp)
  var result = prefix(camel)
  cache[camel] = cache[cssProp] = cache[result] = result
  return result
}

function set () {
  if (arguments.length === 2) {
    if (typeof arguments[1] === 'string') {
      arguments[0].style.cssText = arguments[1]
    } else {
      each(arguments[0], arguments[1])
    }
  } else {
    style(arguments[0], arguments[1], arguments[2])
  }
}

module.exports = set
module.exports.set = set

module.exports.get = function (element, properties) {
  if (Array.isArray(properties)) {
    return properties.reduce(function (obj, prop) {
      obj[prop] = style(element, prop || '')
      return obj
    }, {})
  } else {
    return style(element, properties || '')
  }
}


/***/ }),

/***/ "Q4WQ":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright 2013-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 */



var emptyFunction = __webpack_require__("e6+Q");
var invariant = __webpack_require__("cxPT");
var ReactPropTypesSecret = __webpack_require__("gt/O");

module.exports = function() {
  function shim(props, propName, componentName, location, propFullName, secret) {
    if (secret === ReactPropTypesSecret) {
      // It is still safe when called from React.
      return;
    }
    invariant(
      false,
      'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
      'Use PropTypes.checkPropTypes() to call them. ' +
      'Read more at http://fb.me/use-check-prop-types'
    );
  };
  shim.isRequired = shim;
  function getShim() {
    return shim;
  };
  // Important!
  // Keep this list in sync with production version in `./factoryWithTypeCheckers.js`.
  var ReactPropTypes = {
    array: shim,
    bool: shim,
    func: shim,
    number: shim,
    object: shim,
    string: shim,
    symbol: shim,

    any: shim,
    arrayOf: getShim,
    element: shim,
    instanceOf: getShim,
    node: shim,
    objectOf: getShim,
    oneOf: getShim,
    oneOfType: getShim,
    shape: getShim
  };

  ReactPropTypes.checkPropTypes = emptyFunction;
  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};


/***/ }),

/***/ "QCOB":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports["default"] = getInnerWidth;
function getInnerWidth(el) {
    var clientWidth = el.clientWidth;

    var _getComputedStyle = getComputedStyle(el),
        paddingLeft = _getComputedStyle.paddingLeft,
        paddingRight = _getComputedStyle.paddingRight;

    return clientWidth - parseFloat(paddingLeft) - parseFloat(paddingRight);
}

/***/ }),

/***/ "QuO2":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__deskproapps_deskproapps_sdk_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__deskproapps_deskproapps_sdk_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__deskproapps_deskproapps_sdk_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__main_javascript__ = __webpack_require__("gozv");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__main_javascript___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__main_javascript__);

__webpack_require__("2WNi");


__webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__deskproapps_deskproapps_sdk_react__["createApp"])(__WEBPACK_IMPORTED_MODULE_1__main_javascript__["runApp"]);

/***/ }),

/***/ "SPCo":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getPrototypeOf = __webpack_require__("Zx67");

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__("Zrlr");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__("wxAW");

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__("zwoO");

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__("Pf15");

var _inherits3 = _interopRequireDefault(_inherits2);

var _errorWrapper = __webpack_require__("X4AL");

var _errorWrapper2 = _interopRequireDefault(_errorWrapper);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var TrelloClientError = function (_ErrorWrapper) {
  (0, _inherits3.default)(TrelloClientError, _ErrorWrapper);

  function TrelloClientError(message, originalError, httpResponse) {
    (0, _classCallCheck3.default)(this, TrelloClientError);

    var _this = (0, _possibleConstructorReturn3.default)(this, (TrelloClientError.__proto__ || (0, _getPrototypeOf2.default)(TrelloClientError)).call(this, message, originalError));

    _this.httpResponse = httpResponse;
    return _this;
  }

  (0, _createClass3.default)(TrelloClientError, [{
    key: 'response',
    get: function get() {
      return this.httpResponse;
    }
  }, {
    key: 'code',
    get: function get() {
      return 'TrelloClientError';
    }
  }]);
  return TrelloClientError;
}(_errorWrapper2.default);

exports.default = TrelloClientError;

/***/ }),

/***/ "U5ju":
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__("M6a0");
__webpack_require__("zQR9");
__webpack_require__("+tPU");
__webpack_require__("CXw9");
module.exports = __webpack_require__("FeBl").Promise;

/***/ }),

/***/ "UGHC":
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(process) {// Generated by CoffeeScript 1.12.2
(function() {
  var getNanoSeconds, hrtime, loadTime, moduleLoadTime, nodeLoadTime, upTime;

  if ((typeof performance !== "undefined" && performance !== null) && performance.now) {
    module.exports = function() {
      return performance.now();
    };
  } else if ((typeof process !== "undefined" && process !== null) && process.hrtime) {
    module.exports = function() {
      return (getNanoSeconds() - nodeLoadTime) / 1e6;
    };
    hrtime = process.hrtime;
    getNanoSeconds = function() {
      var hr;
      hr = hrtime();
      return hr[0] * 1e9 + hr[1];
    };
    moduleLoadTime = getNanoSeconds();
    upTime = process.uptime() * 1e9;
    nodeLoadTime = moduleLoadTime - upTime;
  } else if (Date.now) {
    module.exports = function() {
      return Date.now() - loadTime;
    };
    loadTime = Date.now();
  } else {
    module.exports = function() {
      return new Date().getTime() - loadTime;
    };
    loadTime = new Date().getTime();
  }

}).call(this);

//# sourceMappingURL=performance-now.js.map

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__("b2lT")))

/***/ }),

/***/ "UTRz":
/***/ (function(module, exports, __webpack_require__) {


var space = __webpack_require__("0K3L")

/**
 * Export.
 */

module.exports = toCamelCase

/**
 * Convert a `string` to camel case.
 *
 * @param {String} string
 * @return {String}
 */

function toCamelCase(string) {
  return space(string).replace(/\s(\w)/g, function (matches, letter) {
    return letter.toUpperCase()
  })
}


/***/ }),

/***/ "Umix":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _objectWithoutProperties2 = __webpack_require__("+6Bu");

var _objectWithoutProperties3 = _interopRequireDefault(_objectWithoutProperties2);

var _getIterator2 = __webpack_require__("BO1k");

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _deskproappsSdkReact = __webpack_require__(1);

var _CardListComponent = __webpack_require__("oWNz");

var _CardListComponent2 = _interopRequireDefault(_CardListComponent);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * @param {Array<TrelloBoard>} boards
 * @param {Array<TrelloList>} lists
 */
function getFieldsDefinition(boards, lists) {
  return {
    board: {
      schema: {
        type: String,
        optional: false,
        allowedValues: boards.map(function (board) {
          return board.id;
        })
      },
      ui: {
        placeholder: 'Please select',
        label: 'BOARD',
        transform: function transform(id) {
          var _iteratorNormalCompletion = true;
          var _didIteratorError = false;
          var _iteratorError = undefined;

          try {
            for (var _iterator = (0, _getIterator3.default)(boards), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              var board = _step.value;

              if (board.id === id) {
                return board.name;
              }
            }
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion && _iterator.return) {
                _iterator.return();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }
        }
      }
    },
    list: {
      schema: {
        type: String,
        optional: false,
        allowedValues: lists.map(function (list) {
          return list.id;
        })
      },
      ui: {
        placeholder: 'Please select',
        label: 'LIST',
        transform: function transform(id) {
          var _iteratorNormalCompletion2 = true;
          var _didIteratorError2 = false;
          var _iteratorError2 = undefined;

          try {
            for (var _iterator2 = (0, _getIterator3.default)(lists), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              var list = _step2.value;

              if (list.id === id) {
                return list.name;
              }
            }
          } catch (err) {
            _didIteratorError2 = true;
            _iteratorError2 = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion2 && _iterator2.return) {
                _iterator2.return();
              }
            } finally {
              if (_didIteratorError2) {
                throw _iteratorError2;
              }
            }
          }
        }
      }
    }
  };
}

var PickCardSection = function PickCardSection(_ref) {
  var onSelectCard = _ref.onSelectCard,
      onGotoCard = _ref.onGotoCard,
      onCancel = _ref.onCancel,
      onSubmit = _ref.onSubmit,
      onChange = _ref.onChange,
      model = _ref.model,
      boards = _ref.boards,
      lists = _ref.lists,
      cards = _ref.cards,
      otherProps = (0, _objectWithoutProperties3.default)(_ref, ['onSelectCard', 'onGotoCard', 'onCancel', 'onSubmit', 'onChange', 'model', 'boards', 'lists', 'cards']);

  var fields = getFieldsDefinition(boards || [], lists || []);

  return _react2.default.createElement(
    _deskproappsSdkReact.Layout.Section,
    { title: 'PICK AN EXISTING CARD' },
    _react2.default.createElement(
      _deskproappsSdkReact.Form.Form,
      {
        fields: fields,
        model: model,
        onSubmit: onSubmit,
        onChange: onChange,
        onCancel: onCancel
      },
      _react2.default.createElement(_deskproappsSdkReact.Form.Fields, { fields: ['board', 'list'] }),
      _react2.default.createElement(
        _deskproappsSdkReact.Layout.Block,
        { label: 'CARDS' },
        _react2.default.createElement(_CardListComponent2.default, { cards: cards || [], onGotoCard: onGotoCard, onSelectCard: onSelectCard, showCardLocation: false, showBorder: true })
      )
    )
  );
};

PickCardSection.propTypes = {
  model: _react2.default.PropTypes.object,
  cards: _react2.default.PropTypes.array,
  boards: _react2.default.PropTypes.array,
  lists: _react2.default.PropTypes.array,
  onCancel: _react2.default.PropTypes.func,
  onSubmit: _react2.default.PropTypes.func,
  onChange: _react2.default.PropTypes.func,
  onSelectCard: _react2.default.PropTypes.func,
  onGotoCard: _react2.default.PropTypes.func
};

exports.default = PickCardSection;

/***/ }),

/***/ "V5Bl":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports["default"] = getInnerHeight;
function getInnerHeight(el) {
    var clientHeight = el.clientHeight;

    var _getComputedStyle = getComputedStyle(el),
        paddingTop = _getComputedStyle.paddingTop,
        paddingBottom = _getComputedStyle.paddingBottom;

    return clientHeight - parseFloat(paddingTop) - parseFloat(paddingBottom);
}

/***/ }),

/***/ "VVkE":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports["default"] = isString;
function isString(maybe) {
    return typeof maybe === 'string';
}

/***/ }),

/***/ "YyeZ":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {/**
 * Copyright 2014-2015, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 *
 */



var emptyFunction = __webpack_require__("e6+Q");

/**
 * Similar to invariant but only logs a warning if the condition is not met.
 * This can be used to log issues in development environments in critical
 * paths. Removing the logging code for production environments will keep the
 * same logic and follow the same code paths.
 */

var warning = emptyFunction;

if (process.env.NODE_ENV !== 'production') {
  (function () {
    var printWarning = function printWarning(format) {
      for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }

      var argIndex = 0;
      var message = 'Warning: ' + format.replace(/%s/g, function () {
        return args[argIndex++];
      });
      if (typeof console !== 'undefined') {
        console.error(message);
      }
      try {
        // --- Welcome to debugging React ---
        // This error was thrown as a convenience so that you can use this stack
        // to find the callsite that caused this warning to fire.
        throw new Error(message);
      } catch (x) {}
    };

    warning = function warning(condition, format) {
      if (format === undefined) {
        throw new Error('`warning(condition, format, ...args)` requires a warning ' + 'message argument');
      }

      if (format.indexOf('Failed Composite propType: ') === 0) {
        return; // Ignore CompositeComponent proptype check.
      }

      if (!condition) {
        for (var _len2 = arguments.length, args = Array(_len2 > 2 ? _len2 - 2 : 0), _key2 = 2; _key2 < _len2; _key2++) {
          args[_key2 - 2] = arguments[_key2];
        }

        printWarning.apply(undefined, [format].concat(args));
      }
    };
  })();
}

module.exports = warning;
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__("b2lT")))

/***/ }),

/***/ "ZMfs":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.trelloCardToJS = exports.parseTrelloCardFormJS = exports.parseTrelloBoardJS = exports.parseTrelloListJS = exports.parseTrelloCardJS = exports.parseTrelloCardJSList = undefined;

var _keys = __webpack_require__("fZjL");

var _keys2 = _interopRequireDefault(_keys);

var _getIterator2 = __webpack_require__("BO1k");

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _TrelloBoard = __webpack_require__("7ksl");

var _TrelloBoard2 = _interopRequireDefault(_TrelloBoard);

var _TrelloCard = __webpack_require__("ao15");

var _TrelloCard2 = _interopRequireDefault(_TrelloCard);

var _TrelloList = __webpack_require__("7W7s");

var _TrelloList2 = _interopRequireDefault(_TrelloList);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * @param board
 * @return {TrelloBoard}
 */
function parseTrelloBoardJS(board) {
  var id = board.id,
      name = board.name;

  return new _TrelloBoard2.default(id, name);
}

/**
 * @param list
 * @return {TrelloList}
 */
function parseTrelloListJS(list) {
  var id = list.id,
      name = list.name;

  return new _TrelloList2.default(id, name);
}

/**
 * @param card
 * @return {TrelloCard}
 */
function parseTrelloCardJS(card) {
  var list = card.list,
      board = card.board;

  var parsedList = list ? parseTrelloListJS(list) : null;
  var parsedBoard = board ? parseTrelloBoardJS(board) : null;

  var id = card.id,
      name = card.name,
      url = card.url,
      subscribed = card.subscribed,
      desc = card.desc;


  return new _TrelloCard2.default(id, name, url, desc, subscribed, parsedBoard, parsedList);
}

/**
 * @param {{}} formModel
 * @param {Array<TrelloBoard>} boards
 * @param {Array<TrelloList>} lists
 * @return {TrelloCard}
 */
function parseTrelloCardFormJS(formModel, boards, lists) {
  var title = formModel.title,
      description = formModel.description,
      subscribe = formModel.subscribe;


  var boardObject = null;
  if (formModel.board) {
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
      for (var _iterator = (0, _getIterator3.default)(boards), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
        var board = _step.value;

        if (board.id === formModel.board) {
          boardObject = board;
          break;
        }
      }
    } catch (err) {
      _didIteratorError = true;
      _iteratorError = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion && _iterator.return) {
          _iterator.return();
        }
      } finally {
        if (_didIteratorError) {
          throw _iteratorError;
        }
      }
    }
  }

  var listObject = null;
  if (formModel.list) {
    var _iteratorNormalCompletion2 = true;
    var _didIteratorError2 = false;
    var _iteratorError2 = undefined;

    try {
      for (var _iterator2 = (0, _getIterator3.default)(lists), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
        var list = _step2.value;

        if (list.id === formModel.list) {
          listObject = list;
          break;
        }
      }
    } catch (err) {
      _didIteratorError2 = true;
      _iteratorError2 = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion2 && _iterator2.return) {
          _iterator2.return();
        }
      } finally {
        if (_didIteratorError2) {
          throw _iteratorError2;
        }
      }
    }
  }

  return new _TrelloCard2.default(null, title, null, description, subscribe === 'yes', boardObject, listObject);
}

/**
 * @param {TrelloCard} trelloCard
 */
function trelloCardToJS(trelloCard) {

  var source = {
    id: undefined,
    name: undefined,
    url: undefined,
    idList: undefined,
    desc: undefined
  };

  if (trelloCard.id) {
    source.id = trelloCard.id;
  }

  if (trelloCard.name) {
    source.name = trelloCard.name;
  }

  if (trelloCard.description) {
    source.desc = trelloCard.description;
  }

  if (trelloCard.list && trelloCard.list.id) {
    source.idList = trelloCard.list.id;
  }

  var target = {};
  var _iteratorNormalCompletion3 = true;
  var _didIteratorError3 = false;
  var _iteratorError3 = undefined;

  try {
    for (var _iterator3 = (0, _getIterator3.default)((0, _keys2.default)(source)), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
      var key = _step3.value;

      if (undefined !== source[key]) {
        target[key] = source[key];
      }
    }
  } catch (err) {
    _didIteratorError3 = true;
    _iteratorError3 = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion3 && _iterator3.return) {
        _iterator3.return();
      }
    } finally {
      if (_didIteratorError3) {
        throw _iteratorError3;
      }
    }
  }

  return target;
}

var parseTrelloCardJSList = function parseTrelloCardJSList(list) {
  return list.map(function (card) {
    return parseTrelloCardJS(card);
  });
};

exports.parseTrelloCardJSList = parseTrelloCardJSList;
exports.parseTrelloCardJS = parseTrelloCardJS;
exports.parseTrelloListJS = parseTrelloListJS;
exports.parseTrelloBoardJS = parseTrelloBoardJS;
exports.parseTrelloCardFormJS = parseTrelloCardFormJS;
exports.trelloCardToJS = trelloCardToJS;

/***/ }),

/***/ "ZO4r":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _promise = __webpack_require__("//Fk");

var _promise2 = _interopRequireDefault(_promise);

var _classCallCheck2 = __webpack_require__("Zrlr");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _getIterator2 = __webpack_require__("BO1k");

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _assign = __webpack_require__("woOf");

var _assign2 = _interopRequireDefault(_assign);

var _keys = __webpack_require__("fZjL");

var _keys2 = _interopRequireDefault(_keys);

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

var _TrelloApiError = __webpack_require__("6mYA");

var _TrelloApiError2 = _interopRequireDefault(_TrelloApiError);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var superagent = __webpack_require__("GG98");


function isObject(item) {
  return item && (typeof item === 'undefined' ? 'undefined' : (0, _typeof3.default)(item)) === 'object' && !Array.isArray(item) && item !== null;
}

function mergeDeep(target, source) {
  if (isObject(target) && isObject(source)) {
    (0, _keys2.default)(source).forEach(function (key) {
      if (isObject(source[key])) {
        if (!target[key]) (0, _assign2.default)(target, (0, _defineProperty3.default)({}, key, {}));
        mergeDeep(target[key], source[key]);
      } else {
        (0, _assign2.default)(target, (0, _defineProperty3.default)({}, key, source[key]));
      }
    });
  }
  return target;
}

function buildScopeString(scope) {
  var results = [];
  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = (0, _getIterator3.default)((0, _keys2.default)(scope)), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var key = _step.value;

      var e = scope[key];
      if (e) {
        results.push(key);
      }
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator.return) {
        _iterator.return();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  return results.join(',');
}

function buildReturnUrl() {
  return location.protocol + '//' + location.host + location.pathname + location.search;
}

function buildAuthorizationUrl(options, apiKey) {
  var scopeString = buildScopeString(options.scope);
  var returnUrl = buildReturnUrl();
  return 'https://trello.com/1/authorize?response_type=token&key=' + apiKey + '&return_url=' + returnUrl + '&callback_method=postMessage&scope=' + scopeString + '&expiration=' + options.expiration + '&name=' + options.name.replace(/ /g, '+');
}

function buildAuthorizationWindowFeatures() {
  var left = window.screenX + (window.innerWidth - 420) / 2;
  var top = window.screenY + (window.innerHeight - 470) / 2;

  return 'height=606,width=405,left=' + left + ',top=' + top;
}

var TrelloApiClient = function TrelloApiClient(key) {
  (0, _classCallCheck3.default)(this, TrelloApiClient);

  _initialiseProps.call(this);

  this.key = key;
  this.token = null;
  this.get = this.req.bind(this, 'get');
  this.post = this.req.bind(this, 'post');
  this.put = this.req.bind(this, 'put');
  this.del = this.req.bind(this, 'del');
  this.delete = this.req.bind(this, 'del');
};

var _initialiseProps = function _initialiseProps() {
  var _this = this;

  this.setToken = function (token) {
    _this.token = token;
  };

  this.auth = function (opts) {
    var defaults = (0, _assign2.default)({}, {
      type: 'popup',
      name: 'My App',
      scope: {
        read: true,
        write: true,
        account: false
      },
      expiration: '1hour'
    });

    var options = mergeDeep(defaults, opts);
    var authorizationUrl = buildAuthorizationUrl(options, _this.key);
    var authorizationWindowFeatures = buildAuthorizationWindowFeatures();
    var callback = function callback(resolve, reject) {
      var authWindow = window.open(authorizationUrl, 'trello', authorizationWindowFeatures);
      var timeout = setTimeout(function () {
        authWindow.close();return reject();
      }, 60000);

      var receiveMessage = function receiveMessage(event) {
        // return if event.origin != authEndpoint || event.source != authWindow
        if (event.source !== authWindow) {
          return false;
        }
        authWindow.close();
        clearTimeout(timeout);
        window.removeEventListener('message', receiveMessage, false);

        var token = event.data && /[0-9a-f]{64}/.test(event.data) ? event.data : null;
        _this.setToken(token);
        resolve(token);
      };
      window.addEventListener('message', receiveMessage, false);
    };

    return new _promise2.default(callback);
  };

  this.req = function (method, path, data) {

    var req = void 0;
    var token = _this.token,
        key = _this.key;


    if (method === 'get' || method === 'del') {
      req = superagent[method]('https://api.trello.com' + path).query({ key: key, token: token }).query(data);
    } else if (data.file && path.indexOf('attachments') !== -1) {
      req = superagent[method]('https://api.trello.com' + path).query({ key: key, token: token }).field('name', data.name).field('mimeType', data.mimeType);

      if (typeof data.file === 'string') {
        if (window.Blob) {
          req = req.attach('file', new File([data.file], data.name, {
            type: data.mimeType
          }), data.name);
        } else {
          req = req.set({
            'Content-Type': 'boundary=----WebKitFormBoundarygZLBN6gxSW5OC5W1'
          }).send('------WebKitFormBoundarygZLBN6gxSW5OC5W1\r\nContent-Disposition: form-data; name="name"\r\n\r\n' + data.name + '"\r\n------WebKitFormBoundarygZLBN6gxSW5OC5W1\r\nContent-Disposition: form-data; name="mimeType"\r\n\r\n' + data.mimeType + '\r\n------WebKitFormBoundarygZLBN6gxSW5OC5W1\r\nContent-Disposition: form-data; name="key"\r\n\r\n' + key + '\r\n------WebKitFormBoundarygZLBN6gxSW5OC5W1\r\nContent-Disposition: form-data; name="token"\r\n\r\n' + token + '\r\n------WebKitFormBoundarygZLBN6gxSW5OC5W1\r\nContent-Disposition: form-data; name="file"; filename="' + data.name + '"\r\nContent-Type: application/octet-stream\r\n\r\n' + data.file + '\r\n------WebKitFormBoundarygZLBN6gxSW5OC5W1--\r\n');
        }
      } else if ((0, _typeof3.default)(data.file) === 'object' && data.size) {
        req = req.attach('file', data.file, data.name);
      }
    } else {
      req = superagent[method]('https://api.trello.com' + path).query({ key: key, token: token }).type('json').send(data);
    }

    var executor = function executor(resolve, reject) {
      req.end(function (err, res) {
        if (err || !res.ok) {
          var trelloError = new _TrelloApiError2.default('error', err, res);
          reject(trelloError);
        } else {
          resolve(res.body);
        }
      });
    };
    return new _promise2.default(executor);
  };
};

exports.default = TrelloApiClient;

/***/ }),

/***/ "ao15":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _classCallCheck2 = __webpack_require__("Zrlr");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var TrelloCard =

/**
 * @param {String} id
 * @param {String} name
 * @param {String} url
 * @param {String} description
 * @param {boolean} subscribed
 * @param {TrelloBoard} board
 * @param {TrelloList} list
 */
function TrelloCard(id, name, url, description, subscribed, board, list) {
  (0, _classCallCheck3.default)(this, TrelloCard);

  this.id = id;
  this.name = name;
  this.url = url;
  this.description = description;
  this.subscribed = subscribed;
  this.board = board;
  this.list = list;
};

exports.default = TrelloCard;

/***/ }),

/***/ "bOdI":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _defineProperty = __webpack_require__("C4MV");

var _defineProperty2 = _interopRequireDefault(_defineProperty);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (obj, key, value) {
  if (key in obj) {
    (0, _defineProperty2.default)(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
};

/***/ }),

/***/ "bRrM":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global      = __webpack_require__("7KvD")
  , core        = __webpack_require__("FeBl")
  , dP          = __webpack_require__("evD5")
  , DESCRIPTORS = __webpack_require__("+E39")
  , SPECIES     = __webpack_require__("dSzd")('species');

module.exports = function(KEY){
  var C = typeof core[KEY] == 'function' ? core[KEY] : global[KEY];
  if(DESCRIPTORS && C && !C[SPECIES])dP.f(C, SPECIES, {
    configurable: true,
    get: function(){ return this; }
  });
};

/***/ }),

/***/ "c0uK":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _objectWithoutProperties2 = __webpack_require__("+6Bu");

var _objectWithoutProperties3 = _interopRequireDefault(_objectWithoutProperties2);

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _getPrototypeOf = __webpack_require__("Zx67");

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__("Zrlr");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__("wxAW");

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__("zwoO");

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__("Pf15");

var _inherits3 = _interopRequireDefault(_inherits2);

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _semanticUiReact = __webpack_require__("Wz0Z");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var SearchInputComponent = function (_React$Component) {
  (0, _inherits3.default)(SearchInputComponent, _React$Component);

  function SearchInputComponent(props) {
    (0, _classCallCheck3.default)(this, SearchInputComponent);

    var _this = (0, _possibleConstructorReturn3.default)(this, (SearchInputComponent.__proto__ || (0, _getPrototypeOf2.default)(SearchInputComponent)).call(this, props));

    _initialiseProps.call(_this);

    _this.state = { query: '' };
    return _this;
  }

  (0, _createClass3.default)(SearchInputComponent, [{
    key: 'render',
    value: function render() {
      var inputProps = this.filterInputProps(this.props);
      var query = this.state.query;


      return _react2.default.createElement(
        _semanticUiReact.Input,
        (0, _extends3.default)({
          value: query,
          icon: true,
          focus: true,
          onChange: this.handleSearchChange
        }, inputProps),
        _react2.default.createElement('input', { onKeyDown: this.handleOnKeyDown, autofocus: true }),
        _react2.default.createElement(_semanticUiReact.Icon, { name: 'search' })
      );
    }
  }]);
  return SearchInputComponent;
}(_react2.default.Component);

SearchInputComponent.propTypes = {
  onChange: _react2.default.PropTypes.func,
  minCharacters: _react2.default.PropTypes.number
};
SearchInputComponent.defaultProps = {
  onChange: function onChange() {},
  minCharacters: 0
};

var _initialiseProps = function _initialiseProps() {
  var _this2 = this;

  this.handleOnKeyDown = function (e) {
    if (e.keyCode === 13) {
      var query = _this2.state.query;
      var _props = _this2.props,
          onChange = _props.onChange,
          minCharacters = _props.minCharacters;


      if (query.length >= minCharacters && onChange) {
        onChange(query);
      }
    }
  };

  this.handleSearchChange = function (e) {
    e.stopPropagation();
    var newQuery = e.target.value;
    _this2.setState({ query: newQuery });
  };

  this.filterInputProps = function (props) {
    var onChange = props.onChange,
        value = props.value,
        icon = props.icon,
        minCharacters = props.minCharacters,
        allowed = (0, _objectWithoutProperties3.default)(props, ['onChange', 'value', 'icon', 'minCharacters']);

    return allowed;
  };
};

exports.default = SearchInputComponent;

/***/ }),

/***/ "cxPT":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {/**
 * Copyright (c) 2013-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 *
 */



/**
 * Use invariant() to assert state which your program assumes to be true.
 *
 * Provide sprintf-style format (only %s is supported) and arguments
 * to provide information about what broke and what you were
 * expecting.
 *
 * The invariant message will be stripped in production, but the invariant
 * will remain to ensure logic does not differ in production.
 */

var validateFormat = function validateFormat(format) {};

if (process.env.NODE_ENV !== 'production') {
  validateFormat = function validateFormat(format) {
    if (format === undefined) {
      throw new Error('invariant requires an error message argument');
    }
  };
}

function invariant(condition, format, a, b, c, d, e, f) {
  validateFormat(format);

  if (!condition) {
    var error;
    if (format === undefined) {
      error = new Error('Minified exception occurred; use the non-minified dev environment ' + 'for the full error message and additional helpful warnings.');
    } else {
      var args = [a, b, c, d, e, f];
      var argIndex = 0;
      error = new Error(format.replace(/%s/g, function () {
        return args[argIndex++];
      }));
      error.name = 'Invariant Violation';
    }

    error.framesToPop = 1; // we don't care about invariant's own frame
    throw error;
  }
}

module.exports = invariant;
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__("b2lT")))

/***/ }),

/***/ "dEvG":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _getPrototypeOf = __webpack_require__("Zx67");

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__("Zrlr");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__("wxAW");

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__("zwoO");

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__("Pf15");

var _inherits3 = _interopRequireDefault(_inherits2);

var _getIterator2 = __webpack_require__("BO1k");

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _deskproappsSdkReact = __webpack_require__(1);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * @param {Array<TrelloBoard>} boards
 * @param {Array<TrelloList>} lists
 */
var getFieldsDefinition = function getFieldsDefinition(boards, lists) {
    return {
        board: {
            schema: {
                type: String,
                optional: false,
                allowedValues: boards.map(function (board) {
                    return board.id;
                })
            },
            ui: {
                placeholder: 'Please select',
                label: 'BOARD',
                transform: function transform(id) {
                    var _iteratorNormalCompletion = true;
                    var _didIteratorError = false;
                    var _iteratorError = undefined;

                    try {
                        for (var _iterator = (0, _getIterator3.default)(boards), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                            var board = _step.value;

                            if (board.id === id) {
                                return board.name;
                            }
                        }
                    } catch (err) {
                        _didIteratorError = true;
                        _iteratorError = err;
                    } finally {
                        try {
                            if (!_iteratorNormalCompletion && _iterator.return) {
                                _iterator.return();
                            }
                        } finally {
                            if (_didIteratorError) {
                                throw _iteratorError;
                            }
                        }
                    }
                }
            }
        },
        list: {
            schema: {
                type: String,
                optional: false,
                allowedValues: lists.map(function (list) {
                    return list.id;
                })
            },
            ui: {
                placeholder: 'Please select',
                label: 'LIST',
                transform: function transform(id) {
                    var _iteratorNormalCompletion2 = true;
                    var _didIteratorError2 = false;
                    var _iteratorError2 = undefined;

                    try {
                        for (var _iterator2 = (0, _getIterator3.default)(lists), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
                            var list = _step2.value;

                            if (list.id === id) {
                                return list.name;
                            }
                        }
                    } catch (err) {
                        _didIteratorError2 = true;
                        _iteratorError2 = err;
                    } finally {
                        try {
                            if (!_iteratorNormalCompletion2 && _iterator2.return) {
                                _iterator2.return();
                            }
                        } finally {
                            if (_didIteratorError2) {
                                throw _iteratorError2;
                            }
                        }
                    }
                }
            }
        },
        title: {
            schema: {
                type: String,
                optional: false
            }
        },
        description: {
            schema: {
                type: String,
                optional: true
            },
            ui: {
                label: 'DESCRIPTION',
                component: _deskproappsSdkReact.Form.FieldTypes.Textarea
            }
        },
        duedate: {
            schema: {
                type: String,
                optional: true
            },
            ui: {
                placeholder: 'dd / mm / yyyy',
                label: 'DUE DATE'
            }
        },
        labels: {
            schema: {
                type: String,
                optional: true
            },
            ui: {
                placeholder: 'Add by name',
                label: 'LABELS'
            }
        },
        subscribe: {
            schema: {
                type: String,
                defaultValue: 'yes',
                allowedValues: ['yes', 'no'],
                optional: false
            },
            ui: {
                label: 'SUBSCRIBE'
            }
        }
    };
};

var CreateCardSection = function (_React$Component) {
    (0, _inherits3.default)(CreateCardSection, _React$Component);

    function CreateCardSection(props) {
        (0, _classCallCheck3.default)(this, CreateCardSection);

        var _this = (0, _possibleConstructorReturn3.default)(this, (CreateCardSection.__proto__ || (0, _getPrototypeOf2.default)(CreateCardSection)).call(this, props));

        _this.toggleOptionalFieldsVisibility = function () {
            var showOptionalFields = _this.state.showOptionalFields;

            _this.setState({ showOptionalFields: !showOptionalFields });
        };

        _this.state = { showOptionalFields: false };
        return _this;
    }

    (0, _createClass3.default)(CreateCardSection, [{
        key: 'render',
        value: function render() {
            var _props = this.props,
                boards = _props.boards,
                lists = _props.lists;
            var showOptionalFields = this.state.showOptionalFields;

            var fields = getFieldsDefinition(boards, lists);

            var optionalFieldsStyle = {
                display: showOptionalFields ? 'block' : 'none'
            };
            var toggleOptionalFieldsLabel = showOptionalFields ? 'HIDE OPTIONAL FIELDS' : 'SHOW 2 OPTIONAL FIELDS';

            var _props2 = this.props,
                model = _props2.model,
                onSubmit = _props2.onSubmit,
                onChange = _props2.onChange,
                onCancel = _props2.onCancel;

            // <Layout.Block label="ATTACHEMENTS">
            //   <Layout.Button> Choose files </Layout.Button>
            // </Layout.Block>

            return _react2.default.createElement(
                _deskproappsSdkReact.Layout.Section,
                { title: 'CREATE A NEW CARD' },
                _react2.default.createElement(
                    _deskproappsSdkReact.Form.Form,
                    {
                        fields: fields,
                        model: model,
                        submitLabel: "Create card",
                        onSubmit: onSubmit,
                        onChange: onChange,
                        onCancel: onCancel
                    },
                    _react2.default.createElement(_deskproappsSdkReact.Form.Fields, { fields: ['board', 'list', 'title', 'description'] }),
                    _react2.default.createElement(
                        _deskproappsSdkReact.Layout.Block,
                        { style: optionalFieldsStyle },
                        _react2.default.createElement(_deskproappsSdkReact.Form.Fields, { fields: ['duedate', 'labels'] })
                    ),
                    _react2.default.createElement(
                        _deskproappsSdkReact.Layout.Block,
                        null,
                        _react2.default.createElement(
                            'a',
                            { href: '#', onClick: this.toggleOptionalFieldsVisibility, className: 'text small' },
                            toggleOptionalFieldsLabel
                        )
                    )
                )
            );
        }
    }]);
    return CreateCardSection;
}(_react2.default.Component);

CreateCardSection.propTypes = {
    onCancel: _react2.default.PropTypes.func,
    onSubmit: _react2.default.PropTypes.func,
    onChange: _react2.default.PropTypes.func,

    model: _react2.default.PropTypes.object,
    boards: _react2.default.PropTypes.array,
    lists: _react2.default.PropTypes.array
};
CreateCardSection.defaultProps = {
    boards: [],
    lists: []
};
exports.default = CreateCardSection;

/***/ }),

/***/ "e6+Q":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Copyright (c) 2013-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 *
 * 
 */

function makeEmptyFunction(arg) {
  return function () {
    return arg;
  };
}

/**
 * This function accepts and discards inputs; it has no side effects. This is
 * primarily useful idiomatically for overridable function endpoints which
 * always need to be callable, since JS lacks a null-call idiom ala Cocoa.
 */
var emptyFunction = function emptyFunction() {};

emptyFunction.thatReturns = makeEmptyFunction;
emptyFunction.thatReturnsFalse = makeEmptyFunction(false);
emptyFunction.thatReturnsTrue = makeEmptyFunction(true);
emptyFunction.thatReturnsNull = makeEmptyFunction(null);
emptyFunction.thatReturnsThis = function () {
  return this;
};
emptyFunction.thatReturnsArgument = function (arg) {
  return arg;
};

module.exports = emptyFunction;

/***/ }),

/***/ "elAt":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _raf2 = __webpack_require__("ommR");

var _raf3 = _interopRequireDefault(_raf2);

var _domCss = __webpack_require__("PqSB");

var _domCss2 = _interopRequireDefault(_domCss);

var _react = __webpack_require__(0);

var _propTypes = __webpack_require__("KSGD");

var _propTypes2 = _interopRequireDefault(_propTypes);

var _isString = __webpack_require__("VVkE");

var _isString2 = _interopRequireDefault(_isString);

var _getScrollbarWidth = __webpack_require__("nVtj");

var _getScrollbarWidth2 = _interopRequireDefault(_getScrollbarWidth);

var _returnFalse = __webpack_require__("PWsu");

var _returnFalse2 = _interopRequireDefault(_returnFalse);

var _getInnerWidth = __webpack_require__("QCOB");

var _getInnerWidth2 = _interopRequireDefault(_getInnerWidth);

var _getInnerHeight = __webpack_require__("V5Bl");

var _getInnerHeight2 = _interopRequireDefault(_getInnerHeight);

var _styles = __webpack_require__("MoWu");

var _defaultRenderElements = __webpack_require__("J1NI");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Scrollbars = function (_Component) {
    _inherits(Scrollbars, _Component);

    function Scrollbars(props) {
        var _ref;

        _classCallCheck(this, Scrollbars);

        for (var _len = arguments.length, rest = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
            rest[_key - 1] = arguments[_key];
        }

        var _this = _possibleConstructorReturn(this, (_ref = Scrollbars.__proto__ || Object.getPrototypeOf(Scrollbars)).call.apply(_ref, [this, props].concat(rest)));

        _this.handleTrackMouseEnter = _this.handleTrackMouseEnter.bind(_this);
        _this.handleTrackMouseLeave = _this.handleTrackMouseLeave.bind(_this);
        _this.handleHorizontalTrackMouseDown = _this.handleHorizontalTrackMouseDown.bind(_this);
        _this.handleVerticalTrackMouseDown = _this.handleVerticalTrackMouseDown.bind(_this);
        _this.handleHorizontalThumbMouseDown = _this.handleHorizontalThumbMouseDown.bind(_this);
        _this.handleVerticalThumbMouseDown = _this.handleVerticalThumbMouseDown.bind(_this);
        _this.handleWindowResize = _this.handleWindowResize.bind(_this);
        _this.handleScroll = _this.handleScroll.bind(_this);
        _this.handleDrag = _this.handleDrag.bind(_this);
        _this.handleDragEnd = _this.handleDragEnd.bind(_this);

        _this.state = {
            didMountUniversal: false
        };
        return _this;
    }

    _createClass(Scrollbars, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            this.addListeners();
            this.update();
            this.componentDidMountUniversal();
        }
    }, {
        key: 'componentDidMountUniversal',
        value: function componentDidMountUniversal() {
            // eslint-disable-line react/sort-comp
            var universal = this.props.universal;

            if (!universal) return;
            this.setState({ didMountUniversal: true });
        }
    }, {
        key: 'componentDidUpdate',
        value: function componentDidUpdate() {
            this.update();
        }
    }, {
        key: 'componentWillUnmount',
        value: function componentWillUnmount() {
            this.removeListeners();
            (0, _raf2.cancel)(this.requestFrame);
            clearTimeout(this.hideTracksTimeout);
            clearInterval(this.detectScrollingInterval);
        }
    }, {
        key: 'getScrollLeft',
        value: function getScrollLeft() {
            var view = this.refs.view;

            return view.scrollLeft;
        }
    }, {
        key: 'getScrollTop',
        value: function getScrollTop() {
            var view = this.refs.view;

            return view.scrollTop;
        }
    }, {
        key: 'getScrollWidth',
        value: function getScrollWidth() {
            var view = this.refs.view;

            return view.scrollWidth;
        }
    }, {
        key: 'getScrollHeight',
        value: function getScrollHeight() {
            var view = this.refs.view;

            return view.scrollHeight;
        }
    }, {
        key: 'getClientWidth',
        value: function getClientWidth() {
            var view = this.refs.view;

            return view.clientWidth;
        }
    }, {
        key: 'getClientHeight',
        value: function getClientHeight() {
            var view = this.refs.view;

            return view.clientHeight;
        }
    }, {
        key: 'getValues',
        value: function getValues() {
            var view = this.refs.view;
            var scrollLeft = view.scrollLeft,
                scrollTop = view.scrollTop,
                scrollWidth = view.scrollWidth,
                scrollHeight = view.scrollHeight,
                clientWidth = view.clientWidth,
                clientHeight = view.clientHeight;


            return {
                left: scrollLeft / (scrollWidth - clientWidth) || 0,
                top: scrollTop / (scrollHeight - clientHeight) || 0,
                scrollLeft: scrollLeft,
                scrollTop: scrollTop,
                scrollWidth: scrollWidth,
                scrollHeight: scrollHeight,
                clientWidth: clientWidth,
                clientHeight: clientHeight
            };
        }
    }, {
        key: 'getThumbHorizontalWidth',
        value: function getThumbHorizontalWidth() {
            var _props = this.props,
                thumbSize = _props.thumbSize,
                thumbMinSize = _props.thumbMinSize;
            var _refs = this.refs,
                view = _refs.view,
                trackHorizontal = _refs.trackHorizontal;
            var scrollWidth = view.scrollWidth,
                clientWidth = view.clientWidth;

            var trackWidth = (0, _getInnerWidth2["default"])(trackHorizontal);
            var width = Math.ceil(clientWidth / scrollWidth * trackWidth);
            if (trackWidth === width) return 0;
            if (thumbSize) return thumbSize;
            return Math.max(width, thumbMinSize);
        }
    }, {
        key: 'getThumbVerticalHeight',
        value: function getThumbVerticalHeight() {
            var _props2 = this.props,
                thumbSize = _props2.thumbSize,
                thumbMinSize = _props2.thumbMinSize;
            var _refs2 = this.refs,
                view = _refs2.view,
                trackVertical = _refs2.trackVertical;
            var scrollHeight = view.scrollHeight,
                clientHeight = view.clientHeight;

            var trackHeight = (0, _getInnerHeight2["default"])(trackVertical);
            var height = Math.ceil(clientHeight / scrollHeight * trackHeight);
            if (trackHeight === height) return 0;
            if (thumbSize) return thumbSize;
            return Math.max(height, thumbMinSize);
        }
    }, {
        key: 'getScrollLeftForOffset',
        value: function getScrollLeftForOffset(offset) {
            var _refs3 = this.refs,
                view = _refs3.view,
                trackHorizontal = _refs3.trackHorizontal;
            var scrollWidth = view.scrollWidth,
                clientWidth = view.clientWidth;

            var trackWidth = (0, _getInnerWidth2["default"])(trackHorizontal);
            var thumbWidth = this.getThumbHorizontalWidth();
            return offset / (trackWidth - thumbWidth) * (scrollWidth - clientWidth);
        }
    }, {
        key: 'getScrollTopForOffset',
        value: function getScrollTopForOffset(offset) {
            var _refs4 = this.refs,
                view = _refs4.view,
                trackVertical = _refs4.trackVertical;
            var scrollHeight = view.scrollHeight,
                clientHeight = view.clientHeight;

            var trackHeight = (0, _getInnerHeight2["default"])(trackVertical);
            var thumbHeight = this.getThumbVerticalHeight();
            return offset / (trackHeight - thumbHeight) * (scrollHeight - clientHeight);
        }
    }, {
        key: 'scrollLeft',
        value: function scrollLeft() {
            var left = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
            var view = this.refs.view;

            view.scrollLeft = left;
        }
    }, {
        key: 'scrollTop',
        value: function scrollTop() {
            var top = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
            var view = this.refs.view;

            view.scrollTop = top;
        }
    }, {
        key: 'scrollToLeft',
        value: function scrollToLeft() {
            var view = this.refs.view;

            view.scrollLeft = 0;
        }
    }, {
        key: 'scrollToTop',
        value: function scrollToTop() {
            var view = this.refs.view;

            view.scrollTop = 0;
        }
    }, {
        key: 'scrollToRight',
        value: function scrollToRight() {
            var view = this.refs.view;

            view.scrollLeft = view.scrollWidth;
        }
    }, {
        key: 'scrollToBottom',
        value: function scrollToBottom() {
            var view = this.refs.view;

            view.scrollTop = view.scrollHeight;
        }
    }, {
        key: 'addListeners',
        value: function addListeners() {
            /* istanbul ignore if */
            if (typeof document === 'undefined') return;
            var _refs5 = this.refs,
                view = _refs5.view,
                trackHorizontal = _refs5.trackHorizontal,
                trackVertical = _refs5.trackVertical,
                thumbHorizontal = _refs5.thumbHorizontal,
                thumbVertical = _refs5.thumbVertical;

            view.addEventListener('scroll', this.handleScroll);
            if (!(0, _getScrollbarWidth2["default"])()) return;
            trackHorizontal.addEventListener('mouseenter', this.handleTrackMouseEnter);
            trackHorizontal.addEventListener('mouseleave', this.handleTrackMouseLeave);
            trackHorizontal.addEventListener('mousedown', this.handleHorizontalTrackMouseDown);
            trackVertical.addEventListener('mouseenter', this.handleTrackMouseEnter);
            trackVertical.addEventListener('mouseleave', this.handleTrackMouseLeave);
            trackVertical.addEventListener('mousedown', this.handleVerticalTrackMouseDown);
            thumbHorizontal.addEventListener('mousedown', this.handleHorizontalThumbMouseDown);
            thumbVertical.addEventListener('mousedown', this.handleVerticalThumbMouseDown);
            window.addEventListener('resize', this.handleWindowResize);
        }
    }, {
        key: 'removeListeners',
        value: function removeListeners() {
            /* istanbul ignore if */
            if (typeof document === 'undefined') return;
            var _refs6 = this.refs,
                view = _refs6.view,
                trackHorizontal = _refs6.trackHorizontal,
                trackVertical = _refs6.trackVertical,
                thumbHorizontal = _refs6.thumbHorizontal,
                thumbVertical = _refs6.thumbVertical;

            view.removeEventListener('scroll', this.handleScroll);
            if (!(0, _getScrollbarWidth2["default"])()) return;
            trackHorizontal.removeEventListener('mouseenter', this.handleTrackMouseEnter);
            trackHorizontal.removeEventListener('mouseleave', this.handleTrackMouseLeave);
            trackHorizontal.removeEventListener('mousedown', this.handleHorizontalTrackMouseDown);
            trackVertical.removeEventListener('mouseenter', this.handleTrackMouseEnter);
            trackVertical.removeEventListener('mouseleave', this.handleTrackMouseLeave);
            trackVertical.removeEventListener('mousedown', this.handleVerticalTrackMouseDown);
            thumbHorizontal.removeEventListener('mousedown', this.handleHorizontalThumbMouseDown);
            thumbVertical.removeEventListener('mousedown', this.handleVerticalThumbMouseDown);
            window.removeEventListener('resize', this.handleWindowResize);
            // Possibly setup by `handleDragStart`
            this.teardownDragging();
        }
    }, {
        key: 'handleScroll',
        value: function handleScroll(event) {
            var _this2 = this;

            var _props3 = this.props,
                onScroll = _props3.onScroll,
                onScrollFrame = _props3.onScrollFrame;

            if (onScroll) onScroll(event);
            this.update(function (values) {
                var scrollLeft = values.scrollLeft,
                    scrollTop = values.scrollTop;

                _this2.viewScrollLeft = scrollLeft;
                _this2.viewScrollTop = scrollTop;
                if (onScrollFrame) onScrollFrame(values);
            });
            this.detectScrolling();
        }
    }, {
        key: 'handleScrollStart',
        value: function handleScrollStart() {
            var onScrollStart = this.props.onScrollStart;

            if (onScrollStart) onScrollStart();
            this.handleScrollStartAutoHide();
        }
    }, {
        key: 'handleScrollStartAutoHide',
        value: function handleScrollStartAutoHide() {
            var autoHide = this.props.autoHide;

            if (!autoHide) return;
            this.showTracks();
        }
    }, {
        key: 'handleScrollStop',
        value: function handleScrollStop() {
            var onScrollStop = this.props.onScrollStop;

            if (onScrollStop) onScrollStop();
            this.handleScrollStopAutoHide();
        }
    }, {
        key: 'handleScrollStopAutoHide',
        value: function handleScrollStopAutoHide() {
            var autoHide = this.props.autoHide;

            if (!autoHide) return;
            this.hideTracks();
        }
    }, {
        key: 'handleWindowResize',
        value: function handleWindowResize() {
            this.update();
        }
    }, {
        key: 'handleHorizontalTrackMouseDown',
        value: function handleHorizontalTrackMouseDown(event) {
            event.preventDefault();
            var view = this.refs.view;
            var target = event.target,
                clientX = event.clientX;

            var _target$getBoundingCl = target.getBoundingClientRect(),
                targetLeft = _target$getBoundingCl.left;

            var thumbWidth = this.getThumbHorizontalWidth();
            var offset = Math.abs(targetLeft - clientX) - thumbWidth / 2;
            view.scrollLeft = this.getScrollLeftForOffset(offset);
        }
    }, {
        key: 'handleVerticalTrackMouseDown',
        value: function handleVerticalTrackMouseDown(event) {
            event.preventDefault();
            var view = this.refs.view;
            var target = event.target,
                clientY = event.clientY;

            var _target$getBoundingCl2 = target.getBoundingClientRect(),
                targetTop = _target$getBoundingCl2.top;

            var thumbHeight = this.getThumbVerticalHeight();
            var offset = Math.abs(targetTop - clientY) - thumbHeight / 2;
            view.scrollTop = this.getScrollTopForOffset(offset);
        }
    }, {
        key: 'handleHorizontalThumbMouseDown',
        value: function handleHorizontalThumbMouseDown(event) {
            event.preventDefault();
            this.handleDragStart(event);
            var target = event.target,
                clientX = event.clientX;
            var offsetWidth = target.offsetWidth;

            var _target$getBoundingCl3 = target.getBoundingClientRect(),
                left = _target$getBoundingCl3.left;

            this.prevPageX = offsetWidth - (clientX - left);
        }
    }, {
        key: 'handleVerticalThumbMouseDown',
        value: function handleVerticalThumbMouseDown(event) {
            event.preventDefault();
            this.handleDragStart(event);
            var target = event.target,
                clientY = event.clientY;
            var offsetHeight = target.offsetHeight;

            var _target$getBoundingCl4 = target.getBoundingClientRect(),
                top = _target$getBoundingCl4.top;

            this.prevPageY = offsetHeight - (clientY - top);
        }
    }, {
        key: 'setupDragging',
        value: function setupDragging() {
            (0, _domCss2["default"])(document.body, _styles.disableSelectStyle);
            document.addEventListener('mousemove', this.handleDrag);
            document.addEventListener('mouseup', this.handleDragEnd);
            document.onselectstart = _returnFalse2["default"];
        }
    }, {
        key: 'teardownDragging',
        value: function teardownDragging() {
            (0, _domCss2["default"])(document.body, _styles.disableSelectStyleReset);
            document.removeEventListener('mousemove', this.handleDrag);
            document.removeEventListener('mouseup', this.handleDragEnd);
            document.onselectstart = undefined;
        }
    }, {
        key: 'handleDragStart',
        value: function handleDragStart(event) {
            this.dragging = true;
            event.stopImmediatePropagation();
            this.setupDragging();
        }
    }, {
        key: 'handleDrag',
        value: function handleDrag(event) {
            if (this.prevPageX) {
                var clientX = event.clientX;
                var _refs7 = this.refs,
                    view = _refs7.view,
                    trackHorizontal = _refs7.trackHorizontal;

                var _trackHorizontal$getB = trackHorizontal.getBoundingClientRect(),
                    trackLeft = _trackHorizontal$getB.left;

                var thumbWidth = this.getThumbHorizontalWidth();
                var clickPosition = thumbWidth - this.prevPageX;
                var offset = -trackLeft + clientX - clickPosition;
                view.scrollLeft = this.getScrollLeftForOffset(offset);
            }
            if (this.prevPageY) {
                var clientY = event.clientY;
                var _refs8 = this.refs,
                    _view = _refs8.view,
                    trackVertical = _refs8.trackVertical;

                var _trackVertical$getBou = trackVertical.getBoundingClientRect(),
                    trackTop = _trackVertical$getBou.top;

                var thumbHeight = this.getThumbVerticalHeight();
                var _clickPosition = thumbHeight - this.prevPageY;
                var _offset = -trackTop + clientY - _clickPosition;
                _view.scrollTop = this.getScrollTopForOffset(_offset);
            }
            return false;
        }
    }, {
        key: 'handleDragEnd',
        value: function handleDragEnd() {
            this.dragging = false;
            this.prevPageX = this.prevPageY = 0;
            this.teardownDragging();
            this.handleDragEndAutoHide();
        }
    }, {
        key: 'handleDragEndAutoHide',
        value: function handleDragEndAutoHide() {
            var autoHide = this.props.autoHide;

            if (!autoHide) return;
            this.hideTracks();
        }
    }, {
        key: 'handleTrackMouseEnter',
        value: function handleTrackMouseEnter() {
            this.trackMouseOver = true;
            this.handleTrackMouseEnterAutoHide();
        }
    }, {
        key: 'handleTrackMouseEnterAutoHide',
        value: function handleTrackMouseEnterAutoHide() {
            var autoHide = this.props.autoHide;

            if (!autoHide) return;
            this.showTracks();
        }
    }, {
        key: 'handleTrackMouseLeave',
        value: function handleTrackMouseLeave() {
            this.trackMouseOver = false;
            this.handleTrackMouseLeaveAutoHide();
        }
    }, {
        key: 'handleTrackMouseLeaveAutoHide',
        value: function handleTrackMouseLeaveAutoHide() {
            var autoHide = this.props.autoHide;

            if (!autoHide) return;
            this.hideTracks();
        }
    }, {
        key: 'showTracks',
        value: function showTracks() {
            var _refs9 = this.refs,
                trackHorizontal = _refs9.trackHorizontal,
                trackVertical = _refs9.trackVertical;

            clearTimeout(this.hideTracksTimeout);
            (0, _domCss2["default"])(trackHorizontal, { opacity: 1 });
            (0, _domCss2["default"])(trackVertical, { opacity: 1 });
        }
    }, {
        key: 'hideTracks',
        value: function hideTracks() {
            if (this.dragging) return;
            if (this.scrolling) return;
            if (this.trackMouseOver) return;
            var autoHideTimeout = this.props.autoHideTimeout;
            var _refs10 = this.refs,
                trackHorizontal = _refs10.trackHorizontal,
                trackVertical = _refs10.trackVertical;

            clearTimeout(this.hideTracksTimeout);
            this.hideTracksTimeout = setTimeout(function () {
                (0, _domCss2["default"])(trackHorizontal, { opacity: 0 });
                (0, _domCss2["default"])(trackVertical, { opacity: 0 });
            }, autoHideTimeout);
        }
    }, {
        key: 'detectScrolling',
        value: function detectScrolling() {
            var _this3 = this;

            if (this.scrolling) return;
            this.scrolling = true;
            this.handleScrollStart();
            this.detectScrollingInterval = setInterval(function () {
                if (_this3.lastViewScrollLeft === _this3.viewScrollLeft && _this3.lastViewScrollTop === _this3.viewScrollTop) {
                    clearInterval(_this3.detectScrollingInterval);
                    _this3.scrolling = false;
                    _this3.handleScrollStop();
                }
                _this3.lastViewScrollLeft = _this3.viewScrollLeft;
                _this3.lastViewScrollTop = _this3.viewScrollTop;
            }, 100);
        }
    }, {
        key: 'raf',
        value: function raf(callback) {
            var _this4 = this;

            if (this.requestFrame) _raf3["default"].cancel(this.requestFrame);
            this.requestFrame = (0, _raf3["default"])(function () {
                _this4.requestFrame = undefined;
                callback();
            });
        }
    }, {
        key: 'update',
        value: function update(callback) {
            var _this5 = this;

            this.raf(function () {
                return _this5._update(callback);
            });
        }
    }, {
        key: '_update',
        value: function _update(callback) {
            var _props4 = this.props,
                onUpdate = _props4.onUpdate,
                hideTracksWhenNotNeeded = _props4.hideTracksWhenNotNeeded;

            var values = this.getValues();
            if ((0, _getScrollbarWidth2["default"])()) {
                var _refs11 = this.refs,
                    thumbHorizontal = _refs11.thumbHorizontal,
                    thumbVertical = _refs11.thumbVertical,
                    trackHorizontal = _refs11.trackHorizontal,
                    trackVertical = _refs11.trackVertical;
                var scrollLeft = values.scrollLeft,
                    clientWidth = values.clientWidth,
                    scrollWidth = values.scrollWidth;

                var trackHorizontalWidth = (0, _getInnerWidth2["default"])(trackHorizontal);
                var thumbHorizontalWidth = this.getThumbHorizontalWidth();
                var thumbHorizontalX = scrollLeft / (scrollWidth - clientWidth) * (trackHorizontalWidth - thumbHorizontalWidth);
                var thumbHorizontalStyle = {
                    width: thumbHorizontalWidth,
                    transform: 'translateX(' + thumbHorizontalX + 'px)'
                };
                var scrollTop = values.scrollTop,
                    clientHeight = values.clientHeight,
                    scrollHeight = values.scrollHeight;

                var trackVerticalHeight = (0, _getInnerHeight2["default"])(trackVertical);
                var thumbVerticalHeight = this.getThumbVerticalHeight();
                var thumbVerticalY = scrollTop / (scrollHeight - clientHeight) * (trackVerticalHeight - thumbVerticalHeight);
                var thumbVerticalStyle = {
                    height: thumbVerticalHeight,
                    transform: 'translateY(' + thumbVerticalY + 'px)'
                };
                if (hideTracksWhenNotNeeded) {
                    var trackHorizontalStyle = {
                        visibility: scrollWidth > clientWidth ? 'visible' : 'hidden'
                    };
                    var trackVerticalStyle = {
                        visibility: scrollHeight > clientHeight ? 'visible' : 'hidden'
                    };
                    (0, _domCss2["default"])(trackHorizontal, trackHorizontalStyle);
                    (0, _domCss2["default"])(trackVertical, trackVerticalStyle);
                }
                (0, _domCss2["default"])(thumbHorizontal, thumbHorizontalStyle);
                (0, _domCss2["default"])(thumbVertical, thumbVerticalStyle);
            }
            if (onUpdate) onUpdate(values);
            if (typeof callback !== 'function') return;
            callback(values);
        }
    }, {
        key: 'render',
        value: function render() {
            var scrollbarWidth = (0, _getScrollbarWidth2["default"])();
            /* eslint-disable no-unused-vars */

            var _props5 = this.props,
                onScroll = _props5.onScroll,
                onScrollFrame = _props5.onScrollFrame,
                onScrollStart = _props5.onScrollStart,
                onScrollStop = _props5.onScrollStop,
                onUpdate = _props5.onUpdate,
                renderView = _props5.renderView,
                renderTrackHorizontal = _props5.renderTrackHorizontal,
                renderTrackVertical = _props5.renderTrackVertical,
                renderThumbHorizontal = _props5.renderThumbHorizontal,
                renderThumbVertical = _props5.renderThumbVertical,
                tagName = _props5.tagName,
                hideTracksWhenNotNeeded = _props5.hideTracksWhenNotNeeded,
                autoHide = _props5.autoHide,
                autoHideTimeout = _props5.autoHideTimeout,
                autoHideDuration = _props5.autoHideDuration,
                thumbSize = _props5.thumbSize,
                thumbMinSize = _props5.thumbMinSize,
                universal = _props5.universal,
                autoHeight = _props5.autoHeight,
                autoHeightMin = _props5.autoHeightMin,
                autoHeightMax = _props5.autoHeightMax,
                style = _props5.style,
                children = _props5.children,
                props = _objectWithoutProperties(_props5, ['onScroll', 'onScrollFrame', 'onScrollStart', 'onScrollStop', 'onUpdate', 'renderView', 'renderTrackHorizontal', 'renderTrackVertical', 'renderThumbHorizontal', 'renderThumbVertical', 'tagName', 'hideTracksWhenNotNeeded', 'autoHide', 'autoHideTimeout', 'autoHideDuration', 'thumbSize', 'thumbMinSize', 'universal', 'autoHeight', 'autoHeightMin', 'autoHeightMax', 'style', 'children']);
            /* eslint-enable no-unused-vars */

            var didMountUniversal = this.state.didMountUniversal;


            var containerStyle = _extends({}, _styles.containerStyleDefault, autoHeight && _extends({}, _styles.containerStyleAutoHeight, {
                minHeight: autoHeightMin,
                maxHeight: autoHeightMax
            }), style);

            var viewStyle = _extends({}, _styles.viewStyleDefault, {
                // Hide scrollbars by setting a negative margin
                marginRight: scrollbarWidth ? -scrollbarWidth : 0,
                marginBottom: scrollbarWidth ? -scrollbarWidth : 0
            }, autoHeight && _extends({}, _styles.viewStyleAutoHeight, {
                // Add scrollbarWidth to autoHeight in order to compensate negative margins
                minHeight: (0, _isString2["default"])(autoHeightMin) ? 'calc(' + autoHeightMin + ' + ' + scrollbarWidth + 'px)' : autoHeightMin + scrollbarWidth,
                maxHeight: (0, _isString2["default"])(autoHeightMax) ? 'calc(' + autoHeightMax + ' + ' + scrollbarWidth + 'px)' : autoHeightMax + scrollbarWidth
            }), autoHeight && universal && !didMountUniversal && {
                minHeight: autoHeightMin,
                maxHeight: autoHeightMax
            }, universal && !didMountUniversal && _styles.viewStyleUniversalInitial);

            var trackAutoHeightStyle = {
                transition: 'opacity ' + autoHideDuration + 'ms',
                opacity: 0
            };

            var trackHorizontalStyle = _extends({}, _styles.trackHorizontalStyleDefault, autoHide && trackAutoHeightStyle, (!scrollbarWidth || universal && !didMountUniversal) && {
                display: 'none'
            });

            var trackVerticalStyle = _extends({}, _styles.trackVerticalStyleDefault, autoHide && trackAutoHeightStyle, (!scrollbarWidth || universal && !didMountUniversal) && {
                display: 'none'
            });

            return (0, _react.createElement)(tagName, _extends({}, props, { style: containerStyle, ref: 'container' }), [(0, _react.cloneElement)(renderView({ style: viewStyle }), { key: 'view', ref: 'view' }, children), (0, _react.cloneElement)(renderTrackHorizontal({ style: trackHorizontalStyle }), { key: 'trackHorizontal', ref: 'trackHorizontal' }, (0, _react.cloneElement)(renderThumbHorizontal({ style: _styles.thumbHorizontalStyleDefault }), { ref: 'thumbHorizontal' })), (0, _react.cloneElement)(renderTrackVertical({ style: trackVerticalStyle }), { key: 'trackVertical', ref: 'trackVertical' }, (0, _react.cloneElement)(renderThumbVertical({ style: _styles.thumbVerticalStyleDefault }), { ref: 'thumbVertical' }))]);
        }
    }]);

    return Scrollbars;
}(_react.Component);

exports["default"] = Scrollbars;


Scrollbars.propTypes = {
    onScroll: _propTypes2["default"].func,
    onScrollFrame: _propTypes2["default"].func,
    onScrollStart: _propTypes2["default"].func,
    onScrollStop: _propTypes2["default"].func,
    onUpdate: _propTypes2["default"].func,
    renderView: _propTypes2["default"].func,
    renderTrackHorizontal: _propTypes2["default"].func,
    renderTrackVertical: _propTypes2["default"].func,
    renderThumbHorizontal: _propTypes2["default"].func,
    renderThumbVertical: _propTypes2["default"].func,
    tagName: _propTypes2["default"].string,
    thumbSize: _propTypes2["default"].number,
    thumbMinSize: _propTypes2["default"].number,
    hideTracksWhenNotNeeded: _propTypes2["default"].bool,
    autoHide: _propTypes2["default"].bool,
    autoHideTimeout: _propTypes2["default"].number,
    autoHideDuration: _propTypes2["default"].number,
    autoHeight: _propTypes2["default"].bool,
    autoHeightMin: _propTypes2["default"].oneOfType([_propTypes2["default"].number, _propTypes2["default"].string]),
    autoHeightMax: _propTypes2["default"].oneOfType([_propTypes2["default"].number, _propTypes2["default"].string]),
    universal: _propTypes2["default"].bool,
    style: _propTypes2["default"].object,
    children: _propTypes2["default"].node
};

Scrollbars.defaultProps = {
    renderView: _defaultRenderElements.renderViewDefault,
    renderTrackHorizontal: _defaultRenderElements.renderTrackHorizontalDefault,
    renderTrackVertical: _defaultRenderElements.renderTrackVerticalDefault,
    renderThumbHorizontal: _defaultRenderElements.renderThumbHorizontalDefault,
    renderThumbVertical: _defaultRenderElements.renderThumbVerticalDefault,
    tagName: 'div',
    thumbMinSize: 30,
    hideTracksWhenNotNeeded: false,
    autoHide: false,
    autoHideTimeout: 1000,
    autoHideDuration: 200,
    autoHeight: false,
    autoHeightMin: 0,
    autoHeightMax: 200,
    universal: false
};

/***/ }),

/***/ "fZjL":
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__("jFbC"), __esModule: true };

/***/ }),

/***/ "flTs":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _semanticUiReact = __webpack_require__("Wz0Z");

var _deskproappsSdkReact = __webpack_require__(1);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var LinkToCardSection = function LinkToCardSection(_ref) {
  var onCreate = _ref.onCreate,
      onPick = _ref.onPick,
      onSearch = _ref.onSearch;

  return _react2.default.createElement(
    _deskproappsSdkReact.Layout.Section,
    { title: 'LINK TO ANOTHER CARD' },
    _react2.default.createElement(
      _deskproappsSdkReact.Layout.Button,
      { onClick: onSearch },
      'Search for card'
    ),
    _react2.default.createElement(_semanticUiReact.Divider, { hidden: true }),
    _react2.default.createElement(
      _deskproappsSdkReact.Layout.Button,
      { onClick: onPick },
      'Pick card'
    ),
    _react2.default.createElement(_semanticUiReact.Divider, { hidden: true }),
    _react2.default.createElement(
      _deskproappsSdkReact.Layout.Button,
      { onClick: onCreate },
      'Create new card'
    )
  );
};

LinkToCardSection.propTypes = {
  onCreate: _react2.default.PropTypes.func.isRequired,
  onPick: _react2.default.PropTypes.func.isRequired,
  onSearch: _react2.default.PropTypes.func.isRequired
};
exports.default = LinkToCardSection;

/***/ }),

/***/ "gozv":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.runApp = runApp;

var _reactDom = __webpack_require__(2);

var _reactDom2 = _interopRequireDefault(_reactDom);

var _deskproappsSdkReact = __webpack_require__(1);

var _TrelloApp = __webpack_require__("LTvc");

var _TrelloApp2 = _interopRequireDefault(_TrelloApp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function runApp(app) {
  _reactDom2.default.render(React.createElement(_deskproappsSdkReact.DeskproAppContainer, { app: app, name: 'Trello', mainComponent: _TrelloApp2.default }), document.getElementById('deskpro-app'));
}

/***/ }),

/***/ "gt/O":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright 2013-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 */



var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

module.exports = ReactPropTypesSecret;


/***/ }),

/***/ "jFbC":
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__("Cdx3");
module.exports = __webpack_require__("FeBl").Object.keys;

/***/ }),

/***/ "knuC":
/***/ (function(module, exports) {

// fast apply, http://jsperf.lnkit.com/fast-apply/5
module.exports = function(fn, args, that){
  var un = that === undefined;
  switch(args.length){
    case 0: return un ? fn()
                      : fn.call(that);
    case 1: return un ? fn(args[0])
                      : fn.call(that, args[0]);
    case 2: return un ? fn(args[0], args[1])
                      : fn.call(that, args[0], args[1]);
    case 3: return un ? fn(args[0], args[1], args[2])
                      : fn.call(that, args[0], args[1], args[2]);
    case 4: return un ? fn(args[0], args[1], args[2], args[3])
                      : fn.call(that, args[0], args[1], args[2], args[3]);
  } return              fn.apply(that, args);
};

/***/ }),

/***/ "mWvp":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.parseCardURL = undefined;

var _slicedToArray2 = __webpack_require__("d7EF");

var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var parseCardURL = exports.parseCardURL = function parseCardURL(url) {
  var cardRegex = /^https:\/\/trello\.com\/c\/([^\/]+).*$/i;
  var matches = url.match(cardRegex);
  if (matches) {
    var _matches = (0, _slicedToArray3.default)(matches, 2),
        shortLink = _matches[1];

    return { shortLink: shortLink };
  }

  return null;
};

/***/ }),

/***/ "nMX2":
/***/ (function(module, exports) {


/**
 * Export.
 */

module.exports = toNoCase

/**
 * Test whether a string is camel-case.
 */

var hasSpace = /\s/
var hasSeparator = /(_|-|\.|:)/
var hasCamel = /([a-z][A-Z]|[A-Z][a-z])/

/**
 * Remove any starting case from a `string`, like camel or snake, but keep
 * spaces and punctuation that may be important otherwise.
 *
 * @param {String} string
 * @return {String}
 */

function toNoCase(string) {
  if (hasSpace.test(string)) return string.toLowerCase()
  if (hasSeparator.test(string)) return (unseparate(string) || string).toLowerCase()
  if (hasCamel.test(string)) return uncamelize(string).toLowerCase()
  return string.toLowerCase()
}

/**
 * Separator splitter.
 */

var separatorSplitter = /[\W_]+(.|$)/g

/**
 * Un-separate a `string`.
 *
 * @param {String} string
 * @return {String}
 */

function unseparate(string) {
  return string.replace(separatorSplitter, function (m, next) {
    return next ? ' ' + next : ''
  })
}

/**
 * Camelcase splitter.
 */

var camelSplitter = /(.)([A-Z]+)/g

/**
 * Un-camelcase a `string`.
 *
 * @param {String} string
 * @return {String}
 */

function uncamelize(string) {
  return string.replace(camelSplitter, function (m, previous, uppers) {
    return previous + ' ' + uppers.toLowerCase().split('').join(' ')
  })
}


/***/ }),

/***/ "nPmw":
/***/ (function(module, exports) {

var div = null
var prefixes = [ 'Webkit', 'Moz', 'O', 'ms' ]

module.exports = function prefixStyle (prop) {
  // re-use a dummy div
  if (!div) {
    div = document.createElement('div')
  }

  var style = div.style

  // prop exists without prefix
  if (prop in style) {
    return prop
  }

  // borderRadius -> BorderRadius
  var titleCase = prop.charAt(0).toUpperCase() + prop.slice(1)

  // find the vendor-prefixed prop
  for (var i = prefixes.length; i >= 0; i--) {
    var name = prefixes[i] + titleCase
    // e.g. WebkitBorderRadius or webkitBorderRadius
    if (name in style) {
      return name
    }
  }

  return false
}


/***/ }),

/***/ "nVtj":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports["default"] = getScrollbarWidth;

var _domCss = __webpack_require__("PqSB");

var _domCss2 = _interopRequireDefault(_domCss);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var scrollbarWidth = false;

function getScrollbarWidth() {
    if (scrollbarWidth !== false) return scrollbarWidth;
    /* istanbul ignore else */
    if (typeof document !== 'undefined') {
        var div = document.createElement('div');
        (0, _domCss2["default"])(div, {
            width: 100,
            height: 100,
            position: 'absolute',
            top: -9999,
            overflow: 'scroll',
            MsOverflowStyle: 'scrollbar'
        });
        document.body.appendChild(div);
        scrollbarWidth = div.offsetWidth - div.clientWidth;
        document.body.removeChild(div);
    } else {
        scrollbarWidth = 0;
    }
    return scrollbarWidth || 0;
}

/***/ }),

/***/ "oWNz":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _objectWithoutProperties2 = __webpack_require__("+6Bu");

var _objectWithoutProperties3 = _interopRequireDefault(_objectWithoutProperties2);

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _slicedToArray2 = __webpack_require__("d7EF");

var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

var _classCallCheck2 = __webpack_require__("Zrlr");

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__("wxAW");

var _createClass3 = _interopRequireDefault(_createClass2);

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _semanticUiReact = __webpack_require__("Wz0Z");

var _reactCustomScrollbars = __webpack_require__("8ri3");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var CardCommand = function () {
  /**
   * @param {String} name
   * @param {function} handler
   */
  function CardCommand(name, handler) {
    (0, _classCallCheck3.default)(this, CardCommand);

    this.name = name;
    this.handler = handler;
  }

  /**
   * @param {TrelloCard} card
   */


  (0, _createClass3.default)(CardCommand, [{
    key: 'handle',
    value: function handle(card) {
      this.handler(card);
    }
  }]);
  return CardCommand;
}();

var CardOption =
/**
 * @param {String} iconName
 * @param {CardCommand} command
 */
function CardOption(iconName, command) {
  (0, _classCallCheck3.default)(this, CardOption);

  this.iconName = iconName;
  this.command = command;
};

/**
 * @param {Array<TrelloCard>}cardList
 * @param {Array<CardCommand>} commands
 * @return {function(SyntheticEvent)}
 */


function createOnClickHandler(cardList, commands) {
  var commandNames = commands.map(function (command) {
    return command.name;
  });

  var handleCommand = function handleCommand(commandString) {
    var commandParts = commandString.split(':');

    var commandName = null;
    var cardIndex = null;
    if (commandParts instanceof Array && commandParts.length === 2) {
      commandName = commandParts[0];
      cardIndex = parseInt(commandParts[1], 10);
    }

    if (commandNames.indexOf(commandName) === -1 || isNaN(cardIndex) || cardIndex < 0 || cardIndex > cardList.length - 1) {
      return;
    }

    var _commands$filter = commands.filter(function (aCommand) {
      return aCommand.name === commandName;
    }),
        _commands$filter2 = (0, _slicedToArray3.default)(_commands$filter, 1),
        command = _commands$filter2[0];

    var card = cardList[cardIndex];
    command.handle(card);
  };

  /**
   * @param {SyntheticEvent} e
   */
  var handleOnClick = function handleOnClick(e) {
    var target = e.target;

    var optionAttribute = 'data-card-list-command';
    if (target.hasAttribute(optionAttribute)) {
      var command = target.getAttribute(optionAttribute);
      handleCommand(command);
    }
  };

  return handleOnClick;
}

function renderPeopleList(card) {
  return _react2.default.createElement(
    'div',
    null,
    '\xA0'
  );
}

function renderBoardName(card, cardIndex) {
  if (card.board) {
    var commandAttributes = {
      'data-card-list-command': ['selectcard', cardIndex].join(':')
    };
    return _react2.default.createElement(
      'span',
      (0, _extends3.default)({}, commandAttributes, { className: 'small text' }),
      'in ',
      _react2.default.createElement(
        'span',
        (0, _extends3.default)({}, commandAttributes, { className: 'board-name small text' }),
        card.board.name
      )
    );
  }

  return _react2.default.createElement(
    'span',
    null,
    '\xA0'
  );
}

function renderListName(card, cardIndex) {
  var commandAttributes = {
    'data-card-list-command': ['selectcard', cardIndex].join(':')
  };

  if (card.list) {
    return _react2.default.createElement(
      'span',
      (0, _extends3.default)({}, commandAttributes, { className: 'small text' }),
      'on  ',
      _react2.default.createElement(
        'span',
        (0, _extends3.default)({}, commandAttributes, { className: 'list-name small text' }),
        card.list.name
      )
    );
  }

  return _react2.default.createElement(
    'span',
    (0, _extends3.default)({}, commandAttributes, { className: 'small text' }),
    '\xA0'
  );
}

function renderCardLocation(card, cardIndex) {
  var commandAttributes = {
    'data-card-list-command': ['selectcard', cardIndex].join(':')
  };
  return _react2.default.createElement(
    'span',
    (0, _extends3.default)({ className: 'long-content small text' }, commandAttributes),
    renderBoardName(card, cardIndex),
    ' ',
    renderListName(card, cardIndex)
  );
}

function renderTitle(card, cardIndex) {
  var commandAttributes = {
    'data-card-list-command': ['selectcard', cardIndex].join(':')
  };

  return _react2.default.createElement(
    'div',
    (0, _extends3.default)({ className: 'ui header card-title' }, commandAttributes),
    card.name
  );
}

/**
 * @param {TrelloCard} card
 * @param cardIndex
 * @param {CardOption} cardOption
 * @return {XML}
 */
function renderCardOption(card, cardIndex, cardOption) {
  var command = cardOption.command,
      iconName = cardOption.iconName;

  return _react2.default.createElement(_semanticUiReact.Icon, {
    key: ['icon', command.name, card.id].join('-'),
    link: true,
    fitted: true,
    size: 'large',
    name: iconName,
    className: 'option',
    'data-card-list-command': [command.name, cardIndex].join(':')
  });
}

function renderCardOptionsLayout(card, cardIndex, cardOptions) {
  var options = cardOptions.map(function (cardOption) {
    return renderCardOption(card, cardIndex, cardOption);
  });

  if (options.length == 1) {
    return _react2.default.createElement(
      'div',
      { className: 'options-single' },
      _react2.default.createElement(
        'div',
        { className: 'options' },
        _react2.default.createElement(
          'nav',
          null,
          options
        )
      )
    );
  }

  return _react2.default.createElement(
    'div',
    { className: 'options-multiple' },
    _react2.default.createElement(
      'div',
      { className: 'options-hint' },
      _react2.default.createElement('i', { className: 'ellipsis horizontal large icon' })
    ),
    _react2.default.createElement(
      'div',
      { className: 'options' },
      _react2.default.createElement(
        'nav',
        null,
        options
      )
    )
  );
}

/**
 * @param {Object} renderOptions
 * @param {TrelloCard} card
 * @param {Number} cardIndex
 * @param {Array<CardOption>} cardOptions
 */
function renderCard(renderOptions, card, cardIndex, cardOptions) {
  return _react2.default.createElement(
    'div',
    { className: 'ui trelloapp-card-list-item' },
    renderCardOptionsLayout(card, cardIndex, cardOptions),
    _react2.default.createElement(
      'div',
      { className: 'link content', 'data-card-list-command': ['selectcard', cardIndex].join(':') },
      renderTitle(card, cardIndex),
      renderOptions.showCardLocation ? renderCardLocation(card, cardIndex) : null,
      renderPeopleList(card, cardIndex)
    )
  );
}

var CardListComponent = function CardListComponent(_ref) {
  var cards = _ref.cards,
      showCardLocation = _ref.showCardLocation,
      showBorder = _ref.showBorder,
      onGotoCard = _ref.onGotoCard,
      onUnlinkCard = _ref.onUnlinkCard,
      onSelectCard = _ref.onSelectCard;


  if (!cards.length) {
    return _react2.default.createElement('noscript', null);
  }

  var command = null;
  var commands = [];
  var cardOptions = [];

  var renderOptions = { showCardLocation: showCardLocation, showBorder: showBorder };

  if (onGotoCard) {
    command = new CardCommand('gotocard', onGotoCard);
    commands.push(command);
    cardOptions.push(new CardOption('sign in', command));
  }

  if (onUnlinkCard) {
    command = new CardCommand('unlinkcard', onUnlinkCard);
    commands.push(command);
    cardOptions.push(new CardOption('broken chain', command));
  }

  if (onSelectCard) {
    command = new CardCommand('selectcard', onSelectCard);
    commands.push(command);
  }

  var children = cards.map(function (card, cardIndex) {
    return renderCard(renderOptions, card, cardIndex, cardOptions);
  });
  var classNames = ['trelloapp-card-list'];
  if (!showBorder) {
    classNames.push('borderless');
  }
  return _react2.default.createElement(
    'div',
    { onClick: createOnClickHandler(cards, commands), className: classNames.join(' ') },
    _react2.default.createElement(
      _reactCustomScrollbars.Scrollbars,
      { renderThumbVertical: renderScrollbarThumb, autoHeightMax: 400, autoHeight: true, autoHideTimeout: 500 },
      children
    )
  );
};

var renderScrollbarThumb = function renderScrollbarThumb(_ref2) {
  var style = _ref2.style,
      props = (0, _objectWithoutProperties3.default)(_ref2, ['style']);

  var thumbStyle = {
    backgroundColor: "#cccccc",
    zIndex: 400
  };
  return _react2.default.createElement('div', (0, _extends3.default)({
    style: (0, _extends3.default)({}, style, thumbStyle)
  }, props));
};

CardListComponent.propTypes = {
  cards: _react2.default.PropTypes.array.isRequired,
  showCardLocation: _react2.default.PropTypes.bool,
  showBorder: _react2.default.PropTypes.bool,
  onGotoCard: _react2.default.PropTypes.func,
  onUnlinkCard: _react2.default.PropTypes.func,
  onSelectCard: _react2.default.PropTypes.func
};

CardListComponent.defaultProps = {
  showCardLocation: true,
  showBorder: false
};
exports.default = CardListComponent;

/***/ }),

/***/ "ommR":
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {var now = __webpack_require__("UGHC")
  , root = typeof window === 'undefined' ? global : window
  , vendors = ['moz', 'webkit']
  , suffix = 'AnimationFrame'
  , raf = root['request' + suffix]
  , caf = root['cancel' + suffix] || root['cancelRequest' + suffix]

for(var i = 0; !raf && i < vendors.length; i++) {
  raf = root[vendors[i] + 'Request' + suffix]
  caf = root[vendors[i] + 'Cancel' + suffix]
      || root[vendors[i] + 'CancelRequest' + suffix]
}

// Some versions of FF have rAF but not cAF
if(!raf || !caf) {
  var last = 0
    , id = 0
    , queue = []
    , frameDuration = 1000 / 60

  raf = function(callback) {
    if(queue.length === 0) {
      var _now = now()
        , next = Math.max(0, frameDuration - (_now - last))
      last = next + _now
      setTimeout(function() {
        var cp = queue.slice(0)
        // Clear queue here to prevent
        // callbacks from appending listeners
        // to the current frame's queue
        queue.length = 0
        for(var i = 0; i < cp.length; i++) {
          if(!cp[i].cancelled) {
            try{
              cp[i].callback(last)
            } catch(e) {
              setTimeout(function() { throw e }, 0)
            }
          }
        }
      }, Math.round(next))
    }
    queue.push({
      handle: ++id,
      callback: callback,
      cancelled: false
    })
    return id
  }

  caf = function(handle) {
    for(var i = 0; i < queue.length; i++) {
      if(queue[i].handle === handle) {
        queue[i].cancelled = true
      }
    }
  }
}

module.exports = function(fn) {
  // Wrap in a new function to prevent
  // `cancel` potentially being assigned
  // to the native rAF function
  return raf.call(root, fn)
}
module.exports.cancel = function() {
  caf.apply(root, arguments)
}
module.exports.polyfill = function() {
  root.requestAnimationFrame = raf
  root.cancelAnimationFrame = caf
}

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__("BZHq")))

/***/ }),

/***/ "royy":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.parseTrelloCardUrl = exports.TrelloList = exports.TrelloCard = exports.TrelloBoard = exports.TrelloClientError = exports.TrelloClient = exports.TrelloApiError = exports.TrelloApiClient = undefined;

var _TrelloURL = __webpack_require__("mWvp");

Object.defineProperty(exports, 'parseTrelloCardUrl', {
  enumerable: true,
  get: function get() {
    return _TrelloURL.parseCardURL;
  }
});

var _TrelloClient = __webpack_require__("FIGo");

var _TrelloClient2 = _interopRequireDefault(_TrelloClient);

var _TrelloClientError = __webpack_require__("SPCo");

var _TrelloClientError2 = _interopRequireDefault(_TrelloClientError);

var _TrelloApiError = __webpack_require__("6mYA");

var _TrelloApiError2 = _interopRequireDefault(_TrelloApiError);

var _TrelloApiClient = __webpack_require__("ZO4r");

var _TrelloApiClient2 = _interopRequireDefault(_TrelloApiClient);

var _TrelloBoard = __webpack_require__("7ksl");

var _TrelloBoard2 = _interopRequireDefault(_TrelloBoard);

var _TrelloCard = __webpack_require__("ao15");

var _TrelloCard2 = _interopRequireDefault(_TrelloCard);

var _TrelloList = __webpack_require__("7W7s");

var _TrelloList2 = _interopRequireDefault(_TrelloList);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.TrelloApiClient = _TrelloApiClient2.default;
exports.TrelloApiError = _TrelloApiError2.default;
exports.TrelloClient = _TrelloClient2.default;
exports.TrelloClientError = _TrelloClientError2.default;
exports.TrelloBoard = _TrelloBoard2.default;
exports.TrelloCard = _TrelloCard2.default;
exports.TrelloList = _TrelloList2.default;

/***/ }),

/***/ "t2//":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.AuthenticationRequiredPage = exports.SearchCardSection = exports.PickCardSection = exports.LinkToCardSection = exports.LinkedCardsSection = exports.CreateCardSection = undefined;

var _CreateCardSection = __webpack_require__("dEvG");

var _CreateCardSection2 = _interopRequireDefault(_CreateCardSection);

var _LinkedCardsSection = __webpack_require__("yDk2");

var _LinkedCardsSection2 = _interopRequireDefault(_LinkedCardsSection);

var _LinkToCardSection = __webpack_require__("flTs");

var _LinkToCardSection2 = _interopRequireDefault(_LinkToCardSection);

var _PickCardSection = __webpack_require__("Umix");

var _PickCardSection2 = _interopRequireDefault(_PickCardSection);

var _SearchCardSection = __webpack_require__("MXhf");

var _SearchCardSection2 = _interopRequireDefault(_SearchCardSection);

var _AuthenticationRequiredPage = __webpack_require__("GACX");

var _AuthenticationRequiredPage2 = _interopRequireDefault(_AuthenticationRequiredPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.CreateCardSection = _CreateCardSection2.default;
exports.LinkedCardsSection = _LinkedCardsSection2.default;
exports.LinkToCardSection = _LinkToCardSection2.default;
exports.PickCardSection = _PickCardSection2.default;
exports.SearchCardSection = _SearchCardSection2.default;
exports.AuthenticationRequiredPage = _AuthenticationRequiredPage2.default;

/***/ }),

/***/ "t8x9":
/***/ (function(module, exports, __webpack_require__) {

// 7.3.20 SpeciesConstructor(O, defaultConstructor)
var anObject  = __webpack_require__("77Pl")
  , aFunction = __webpack_require__("lOnJ")
  , SPECIES   = __webpack_require__("dSzd")('species');
module.exports = function(O, D){
  var C = anObject(O).constructor, S;
  return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? D : aFunction(S);
};

/***/ }),

/***/ "xH/j":
/***/ (function(module, exports, __webpack_require__) {

var hide = __webpack_require__("hJx8");
module.exports = function(target, src, safe){
  for(var key in src){
    if(safe && target[key])target[key] = src[key];
    else hide(target, key, src[key]);
  } return target;
};

/***/ }),

/***/ "yDk2":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _deskproappsSdkReact = __webpack_require__(1);

var _CardListComponent = __webpack_require__("oWNz");

var _CardListComponent2 = _interopRequireDefault(_CardListComponent);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var LinkedCardsSection = function LinkedCardsSection(_ref) {
  var cards = _ref.cards,
      onGotoCard = _ref.onGotoCard,
      onUnlinkCard = _ref.onUnlinkCard,
      onSelectCard = _ref.onSelectCard;

  if (!cards || !cards.length) {
    return null;
  }

  return _react2.default.createElement(
    _deskproappsSdkReact.Layout.Section,
    { title: 'LINKED CARDS' },
    _react2.default.createElement(_CardListComponent2.default, { cards: cards, onGotoCard: onGotoCard, onUnlinkCard: onUnlinkCard, onSelectCard: onSelectCard })
  );
};

LinkedCardsSection.propTypes = {
  cards: _react2.default.PropTypes.array.isRequired,
  onGotoCard: _react2.default.PropTypes.func,
  onUnlinkCard: _react2.default.PropTypes.func,
  onSelectCard: _react2.default.PropTypes.func
};
exports.default = LinkedCardsSection;

/***/ })

},[3]);
//# sourceMappingURL=main.js.map