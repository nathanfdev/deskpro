import * as React from 'react';
import { EditorOptions } from '@deskpro/content-editor';
import { ReactEditor, ToolbarAction, ReactEditorProps } from '@deskpro/react-content-editor';
declare type Props = {
    options?: EditorOptions;
    label?: string;
    placeholder?: string;
    maxHeight?: string;
    toolbarActions?: ToolbarAction[];
    onFocus?: () => void;
    onBlur?: () => void;
};
export default class ArticleEditor extends React.PureComponent<Props & ReactEditorProps> {
    reactEditor: React.RefObject<ReactEditor>;
    readonly editor: import("@deskpro/content-editor").Editor | undefined;
    render(): JSX.Element;
}
export {};
