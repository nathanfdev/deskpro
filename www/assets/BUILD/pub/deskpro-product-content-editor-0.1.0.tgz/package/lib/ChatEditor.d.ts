import * as React from 'react';
import { EditorOptions } from '@deskpro/content-editor';
declare type Props = {
    options?: EditorOptions;
    label?: string;
    placeholder?: string;
    maxHeight?: string;
    onFocus?: () => void;
    onBlur?: () => void;
};
declare type State = {
    content: string;
};
export default class ChatEditor extends React.PureComponent<Props, State> {
    constructor(props: Props);
    render(): JSX.Element;
}
export {};
