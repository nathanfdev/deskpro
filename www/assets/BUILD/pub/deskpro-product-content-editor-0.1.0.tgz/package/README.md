
# DeskPro ProseMirror Editor: DeskPro Custom Editors
> This package contains specific editor implementations for use directly by DeskPro.

## Usage
TODO: write documentation
